<script language="JavaScript" type="text/javascript">
  function addSmiley(textToAdd){
  document.formshout.pesan.value += textToAdd;
  document.formshout.pesan.focus();
}
</script>
<?php
// Shoutbox
echo "<br><br> ";
echo "<h3> Mini Chat </h3>";
echo "<iframe src='shoutbox.php' width=178 height=250 border=0 solid bgcolor=white ></iframe><br />";
echo "<table align='left'>
        <form name=formshout action=simpanshoutbox.php method=POST>
        <tr><td>Nama</td><td> : <input class=shout type=text name=nama size=20></td></tr>
        <tr><td>Website</td><td> : <input class=shout type=text name=website size=20></td></tr>
        <tr><td valign=top>Pesan</td><td> : <textarea class=shout name='pesan' style='width: 140px; height: 60px;'></textarea></td></tr>";
  ?>
        <tr><td colspan=6>
        <a onClick="addSmiley(':-)')"><img src='smiley/1.gif'></a> 
        <a onClick="addSmiley(':-(')"><img src='smiley/2.gif'></a>
        <a onClick="addSmiley(';-)')"><img src='smiley/3.gif'></a>
        <a onClick="addSmiley(';-D')"><img src='smiley/4.gif'></a>
        <a onClick="addSmiley(';;-)')"><img src='smiley/5.gif'></a>
        <a onClick="addSmiley('<:D>')"><img src='smiley/6.gif'></a>
        </td></tr>
  <?php
  echo "<tr><td colspan=3><input class=shout type=submit name=submit value=Kirim><input class=shout type=reset name=reset value=Reset></td></tr>
        </form></table><br />";

?>