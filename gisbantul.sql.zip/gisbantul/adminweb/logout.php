<?php
  session_start();
  session_destroy();
  echo "<center><b>Anda telah sukses keluar sistem.</b><p> klick <a href=index.php>Login</a> untuk kembali masuk atau klick <a href=../index.php> home</a> untuk kembali ke halaman utama";

// Apabila setelah logout langsung menuju halaman utama website, aktifkan baris di bawah ini:

?>
