<?php
$aksi="modul/mod_tentangkami/aksi_tentangkami.php";
switch($_GET[act]){
  // Tampil Komentar
  default:
    $sql  = mysql_query("SELECT * FROM modul WHERE id_modul='63'");
    $r    = mysql_fetch_array($sql);

    echo "<h2>Tentang Kami</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=tentangkami&act=update>
          <input type=hidden name=id value=$r[id_modul]>
          <table style='border: 1pt dashed #999999; padding: 10px;'>
          <tr><td><img src=../foto_banner/$r[gambar]></td></tr>
         <tr><td>Ganti Foto : <input type=file size=30 name=fupload></td></tr>
         <tr><td><textarea name='isi' style='width: 666px; height: 300px;'>$r[static_content]</textarea></td></tr>
         <tr><td><input type=submit value=Update></td></tr>
         </form></table>";
    break;
}
?>
