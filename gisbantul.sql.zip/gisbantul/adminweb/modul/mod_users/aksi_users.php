<?php
session_start();
include "../../../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];

// Input user
if ($module=='user' AND $act=='input'){
  $pass=md5($_POST[password]);
  mysql_query("INSERT INTO users(username,
                                 password,
                                 nama_instansi,
								 alamat,
                                 email,
								 jabatan, 
                                 no_telp,
                                 id_session) 
	                       VALUES('$_POST[username]',
                                '$pass',
                                '$_POST[nama_instansi]',
								'$_POST[alamat]',
								'$_POST[jabatan]',
                                '$_POST[email]',
                                '$_POST[no_telp]',
                                '$pass')");
  header('location:../../media.php?module='.$module);
}

// Update user
elseif ($module=='user' AND $act=='update'){
  if (empty($_POST[password])) {
    mysql_query("UPDATE users SET nama_instansi   = '$_POST[nama_instansi]',
	                              alamat          = '$_POST[alamat]',
								  jabatan         = '$_POST[jabatan]',
                                  email           = '$_POST[email]',
                                  blokir          = '$_POST[blokir]',  
                                  no_telp         = '$_POST[no_telp]'  
                           WHERE  id_session      = '$_POST[id]'");
  }
  // Apabila password diubah
  else{
    $pass=md5($_POST[password]);
    mysql_query("UPDATE users SET password        = '$pass',
                                 nama_instansi    = '$_POST[nama_instansi]',
								 alamat          = '$_POST[alamat]',
								 jabatan        = '$_POST[jabatan]',
                                 email           = '$_POST[email]',  
                                 blokir          = '$_POST[blokir]',  
                                 no_telp         = '$_POST[no_telp]'  
                           WHERE id_session      = '$_POST[id]'");
  }
  header('location:../../media.php?module='.$module);
}
?>
