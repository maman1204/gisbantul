<?php
$aksi="modul/mod_sekilaslink/aksi_sekilaslink.php";
switch($_GET[act]){
  // Tampil Sekilas link
  default:
    echo "<h2>Sekilas link</h2>
          <input type=button value='Tambah Sekilas link' onclick=location.href='?module=sekilaslink&act=tambahsekilaslink'>
          <table  style='border: 1pt dashed #999999; padding: 10px;'>
          <tr><th>no</th><th>nama link</th><th>url</th><th>tgl. posting</th><th>aksi</th></tr>";
    $tampil=mysql_query("SELECT * FROM sekilaslink ORDER BY id_link DESC");
    $no=1;
    while ($r=mysql_fetch_array($tampil)){
      $tgl=tgl_indo($r[tgl_posting]);
      echo "<tr><td>$no</td>
                <td>$r[nama_link]</td>
				<td>$r[url]</td>
                <td>$tgl</td>
                <td><a href=?module=sekilaslink&act=editsekilaslink&id=$r[id_link]>Edit</a> | 
	                  <a href=$aksi?module=sekilaslink&act=hapus&id=$r[id_link]>Hapus</a>
		        </tr>";
    $no++;
    }
    echo "</table>";
    break;
  
  case "tambahsekilaslink":
    echo "<h2>Tambah Sekilas link</h2>
          <form method=POST action='$aksi?module=sekilaslink&act=input' >
          <table width=100% style='border: 1pt dashed #999999; padding: 10px;'>
          <tr><td>nama_link</td><td>  : <input type=text name='nama_link' size=100></td></tr>
		  <tr><td>url</td><td>  : <input type=text name='url' size=100></td></tr>
          <tr><td colspan=2><input type=submit value=Simpan>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form><br><br><br>";
     break;
    
  case "editsekilaslink":
    $edit = mysql_query("SELECT * FROM sekilaslink WHERE id_link='$_GET[id]'");
    $r    = mysql_fetch_array($edit);

    echo "<h2>Edit Sekilas link</h2>
          <form method=POST  action=$aksi?module=sekilaslink&act=update>

          <table width=100% style='border: 1pt dashed #999999; padding: 10px;'>
          <tr><td>Nama Link</td><td>     : <input type=text name='nama_link' size=100 value='$r[nama_link]'></td></tr>
         <tr><td>url</td><td>     : <input type=text name='url' size=100 value='$r[url]'></td></tr>
          <tr><td colspan=2><input type=submit value=Update>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
    break;  
}
?>
