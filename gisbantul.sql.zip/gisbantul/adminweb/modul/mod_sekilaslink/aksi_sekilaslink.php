<?php
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus sekilas link
if ($module=='sekilaslink' AND $act=='hapus'){
  mysql_query("DELETE FROM sekilaslink WHERE id_link='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input sekilas link
elseif ($module=='sekilaslink' AND $act=='input'){


  
    mysql_query("INSERT INTO sekilaslink(nama_link,
	                                 url,
                                    tgl_posting) 
                            VALUES('$_POST[nama_link]',
							       '$_POST[url]',
                                   '$tgl_sekarang')");
  
  header('location:../../media.php?module='.$module);
}

// Update sekilas link
elseif ($module=='sekilaslink' AND $act=='update'){

    mysql_query("UPDATE sekilaslink SET nama_link = '$_POST[nama_link]'
	                                url = '$_POST[url]' 
                             WHERE id_link = '$_POST[id]'");

  header('location:../../media.php?module='.$module);
}
?>
