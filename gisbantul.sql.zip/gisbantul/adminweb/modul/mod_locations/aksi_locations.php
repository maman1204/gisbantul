<?php
session_start();
ob_start();
error_reporting(0);
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";
include "../../../config/fungsi_seo.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus locations
if ($module=='locations' AND $act=='hapus'){
  mysql_query("DELETE FROM locations WHERE id_locations='$_GET[id]'");
  unlink("../../../foto_locations/$_GET[namafile]");   
  unlink("../../../foto_locations/small_$_GET[namafile]");   
  header('location:../../media.php?module='.$module);
}

// Input locations
elseif ($module=='locations' AND $act=='input'){

        $id_locations = $_POST['id_locations'];
		
		$judul = $_POST['judul'];
		$description = $_POST['description'];
		
		$lat = $_POST['lat'];
		$long = $_POST['long'];
		$address = $_POST['address'];
		$telepon = $_POST['telepon'];
        $nobangunan = $_POST['nobangunan'];
		$kodepos = $_POST['kodepos'];

		
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);

  $nama_file_unik  = $acak.$nama_file; 
  
 $lokasi_file2    = $_FILES['fupload2']['tmp_name'];
  $tipe_file2      = $_FILES['fupload2']['type'];
  $nama_file2      = $_FILES['fupload2']['name'];
  $acak2           = rand(1,99);

  $nama_file_unik2  = $acak2.$nama_file2; 
  
  $judul_seo      = seo_title($_POST['judul']);
$lokasi_file3  = $lokasi_file.$lokasi_file2; 
  // Apabila ada gambar yang diupload
  if (!empty($lokasi_file3)){
    UploadImage($nama_file_unik);
	UploadImage2($nama_file_unik2);

    mysql_query("INSERT INTO locations(judul,
                                    judul_seo,
                                    id_kategori,
                                    username,
									latitude,
								    longitude,
								    address,
									nobangunan,
                                    telepon,
									kodepos,
                                    description,
                                    jam,
                                    tanggal,
                                    hari,
                                    gambar,
									gambar2) 
                            VALUES('$_POST[judul]',
                                   '$judul_seo',
                                   '$_POST[kategori]',
                                   '$_SESSION[namauser]',
								   '$lat',
								   '$long', 
								   '$address', 
								   '$nobangunan',
								   '$telepon', 
								   '$kodepos', 
                                   '$_POST[description]',
                                   '$jam_sekarang',
                                   '$tgl_sekarang',
                                   '$hari_ini',
                                   '$nama_file_unik',
								   '$nama_file_unik2')");
  }
  
  else{
    mysql_query("INSERT INTO locations(judul,
                                    judul_seo,
                                    id_kategori,
                                    username,
									latitude,
								    longitude,
								    address,
									nobangunan,
								    telepon,
									kodepos,
                                    description,
                                    jam,
                                    tanggal,
                                    hari) 
                            VALUES('$_POST[judul]',
                                   '$judul_seo',
                                   '$_POST[kategori]',
                                   '$_SESSION[namauser]',
								   '$lat',
								   '$long', 
								   '$address', 
								   '$nobangunan',
								   '$telepon', 
								   '$kodepos', 
                                   '$_POST[description]',
                                   '$jam_sekarang',
                                   '$tgl_sekarang',
                                   '$hari_ini')");
  }
  
  
  header('location:../../media.php?module='.$module);
}

// Update locations
elseif ($module=='locations' AND $act=='update'){
 
  $judul = $_POST['judul'];
		$description = $_POST['description'];
		
		$lat = $_POST['latitude'];
		$long = $_POST['longitude'];
		$address = $_POST['address'];
	    $telepon = $_POST['telepon'];
		$nobangunan = $_POST['nobangunan'];
		$kodepos = $_POST['kodepos'];
		
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 
  
 $lokasi_file2    = $_FILES['fupload2']['tmp_name'];
  $tipe_file2      = $_FILES['fupload2']['type'];
  $nama_file2      = $_FILES['fupload2']['name'];
  $acak2           = rand(1,99);

  $nama_file_unik2  = $acak2.$nama_file2; 
  
  $judul_seo      = seo_title($_POST['judul']);

 $lokasi_file3  = $lokasi_file.$lokasi_file2; 
   
 
  // Apabila gambar tidak diganti
  if (empty($lokasi_file3)){
    mysql_query("UPDATE locations SET 
	                               judul     = '$_POST[judul]',
                                   judul_seo    = '$judul_seo', 
                                   id_kategori  = '$_POST[kategori]',
								   latitude     = '$_POST[lat]',
								   longitude    = '$_POST[long]',
								   address      = '$_POST[address]',
								   nobangunan   = '$_POST[nobangunan]',
								   telepon      = '$_POST[telepon]',
								   kodepos      = '$_POST[kodepos]',
                                   description  = '$_POST[description]'  
								   
                             WHERE id_locations   = '$_POST[id]'");
  }
  else{
    UploadImage($nama_file_unik);
	UploadImage2($nama_file_unik2);
    mysql_query("UPDATE locations SET judul     = '$_POST[judul]',
                                   judul_seo    = '$judul_seo', 
                                   id_kategori  = '$_POST[kategori]',
								   latitude     = '$_POST[lat]',
								   longitude    = '$_POST[long]',
								   address      = '$_POST[address]',
								   nobangunan   = '$_POST[nobangunan]',
								   telepon      = '$_POST[telepon]',
								   kodepos      = '$_POST[kodepos]',
								   description  = '$_POST[description]',
                                   gambar       = '$nama_file_unik',
								   gambar2      = '$nama_file_unik2'    
                             WHERE id_locations   = '$_POST[id]'");
  }
  
  header('location:../../media.php?module='.$module);
}
?>
