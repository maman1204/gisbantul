<div id='map_canvas' ></div>

 <?php
		$locations = mysql_query("SELECT * FROM locations,users,kategori  
                      WHERE users.username=locations.username 
                      AND kategori.id_kategori=locations.id_kategori");
		$nr_locations = mysql_num_rows($locations);
		
	
		
			// find locations from db
				// save data for locations
		    $ids = "";			// string with latitude values
			$juds = "";			// string with longitude values
			$lats = "";			// string with latitude values
			$lngs = "";			// string with longitude values
			$addresses = "";	// string with address values
			$names = "";		// string with names
			$descrs = "";		// string with descriptions6
			$luasbs = "";		// string with luas bangunan
			$hargas = "";		// string with harga sewa
			$namals = "";		// string with nama lengkap
			$nops = "";		    // string with no telpon
			$gambars = "";		// string with photo names
			$user_names = "";	// string with user names
			$user_locs = "";	// string with user locations
			$jens       = "";	// string with user locations

			
			$i=0; 
			
			// take the locations from the db one by one
			while ($locat = mysql_fetch_array($locations))
			{
				// add lcoation data to info strings
			    $ids .= $locat['id_locations'].";;";
				$juds .= $locat['judul_seo'].";;";
				$lats .= $locat['latitude'].";;";
				$lngs .= $locat['longitude'].";;";
				$addresses .= $locat['address'].";;";
				$names .= $locat['judul'].";;";
				$descrs .= $locat['description'].";;";
				$luasbs .= $locat['luas_bangunan'].";;";
				$hargas .= $locat['harga'].";;";
				$namals .= $locat['nama_lengkap'].";;";
				$nops .= $locat['no_telp'].";;";
				$gambars .= $locat['gambar'].";;";
				$user_names .= $locat['user_name'].";;";
				$user_locs .= $locat['user_location'].";;";
				$jens .= $locat['jenis'].";;";

				 
				// show the location name in the right of the map with link that calls the highlightMarker function
			
				$i++;
				
			
			}
			// hidden inputs for saving the info for all the locations in the db
			
            echo"
			<input type=hidden value='$ids;' id='ids' name='ids'/>
			<input type=hidden value='$juds;' id='juds' name='juds'/>
			<input type=hidden value='$lats;' id='lats' name='lats'/>
			<input type=hidden value='$lngs;' id='lngs' name='lngs'/>
			<input type=hidden value='$addresses;' id='addresses' name='addresses'/>
			<input type=hidden value='$names;' id='names' name='names'/>
			<input type=hidden value='$descrs;' id='descrs' name='descrs'/>
			<input type=hidden value='$luasbs;' id='luasbs' name='luasbs'/>
			<input type=hidden value='$hargas;' id='hargas' name='hargas'/>
			<input type=hidden value='$namals;' id='namals' name='namals'/>
			<input type=hidden value='$nops;' id='nops' name='nops'/>
			<input type=hidden value='$gambars;' id='gambars' name='gambars'/>
			<input type=hidden value='$user_names;' id='user_names' name='user_names'/>
			<input type=hidden value='$user_locs;' id='user_locs' name='user_locs'/>
			<input type=hidden value='$jens;' id='jens' name='jens'/>";
            

			
?>
			

<?php

$aksi="modul/mod_locations/aksi_locations.php";
switch($_GET[act]){
  // Tampil locations
  default:
    echo "<h2>Data Instansi</h2>
          <input type=button value='Tambah Lokasi Instansi' onclick=\"window.location.href='?module=locations&act=tambahlocations';\">
          <table width=100% style='border: 1pt dashed #CCC; padding: 10px; background-color:#FFFFCC;'>
          <tr><th>no</th><th>Nama Id Object</th><th>Lokasi</th><th>Keberadaan</th><th>tgl. posting</th><th>aksi</th></tr>";

    $p      = new Paging;
    $batas  = 12;
    $posisi = $p->cariPosisi($batas);

    if ($_SESSION[leveluser]=='admin'){
      $tampil = mysql_query("SELECT * FROM locations ORDER BY id_locations DESC LIMIT $posisi,$batas");
    }
    else{
      $tampil=mysql_query("SELECT * FROM locations 
                           WHERE username='$_SESSION[namauser]'       
                           ORDER BY id_locations DESC LIMIT 0,1");
    }
  
    $no = $posisi+1;
    while($r=mysql_fetch_array($tampil)){
      $tgl_posting=tgl_indo($r[tanggal]);
      echo "<tr><td>$no</td>
                <td>$r[judul]</td>
				<td>$r[address]</td>
				<td>$r[telepon]</td>
				
                <td>$tgl_posting</td>
		            <td><a href=?module=locations&act=editlocations&id=$r[id_locations]>Edit</a> | 
		                <a href='$aksi?module=locations&act=hapus&id=$r[id_locations]&namafile=$r[gambar]'>Hapus</a></td>
		        </tr>";
      $no++;
    }
    echo "</table>";

    if ($_SESSION[leveluser]=='admin'){
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM locations"));
    }
    else{
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM locations WHERE username='$_SESSION[namauser]'"));
    }  
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";
 
    break;
	
  case "tambahlocations":
 		
    echo "   <div style='opacity: 0.7; position: absolute; top: 298px; left: 338px; display: none;' class='tooltip'></div>
          <form id='myform' method=POST action='$aksi?module=locations&act=input' enctype='multipart/form-data'>
          <table width=100% style='border: 1pt dashed #CCC; padding: 10px; background-color:#FFFFCC;'>
         
		  <tr><td width=120>Nama Id Object</td>     <td> : <input type=text name='judul' size=60 title='Isikan nama / identitas.'></td></tr>
          <tr><td>Nama Objek</td>  <td> : 
          <select name='kategori' title='Pilih salah satu kategori.'>
            <option value=0 selected >- Pilih Kategori -</option>";
            $tampil=mysql_query("SELECT * FROM kategori ORDER BY nama_kategori");
            while($r=mysql_fetch_array($tampil)){
              echo "<option value=$r[id_kategori] onChange='setjenis(this.value)'>$r[nama_kategori] </option>";
            }
    echo "</select></td></tr>
	
	
		
		<tr><td><b>Kordinat</b></td><td>: 
			    <input name=lat type=text id='lat' title='Latitude Terisi Jika Peta Ditekan' size='25'/>&nbsp; &nbsp;&nbsp;<input name=long id='long' type=text title='Longitude Terisi Jika Peta Ditekan' size='25' /></td></tr>
			  <tr><td><b>Lokasi</b></td><td> : <input name=address id='address' type=text title='Otomatis Terisi Jika Peta Ditekan' size='70' /></td></tr>
			  <tr><td>Kondisi</td>     <td> : <input type=text name='nobangunan' title='Masukan Nomor Bangunan' size=10></td></tr>
			  
 <tr><td>Keberadaan</td>     <td> : <input type=text name='telepon' size=20 title='isi dengan no telepon.'></td></tr>
  <tr><td>Tahun Anggaran</td>     <td> : <input type=text name='kodepos' size=20 title='isi dengan kode pos.'></td></tr>
           <tr><td>Keterangan</td>  <td><textarea  name='description' title='penjelassan' style='width: 550px; height: 320px;' ></textarea></td></tr>
          <tr><td>Gambar 1</td>      <td> : <input type=file name='fupload' title='Tipe gambar harus JPG/JPEG dan ukuran lebar maks: 400 px.' size=40></td></tr>
		  <tr><td>Gambar 2</td>      <td> : <input type=file name='fupload2' title='Tipe gambar harus JPG/JPEG dan ukuran lebar maks: 400 px.' size=40></td></tr>";
    echo "</td></tr>
          <tr><td colspan=2><input type=submit value=Simpan title='Pastikan data telah terisi dengan benar'>
                            <input type=button value=Batal title='Untuk Membatalkan' onclick=self.history.back()></td></tr>
          </table></form>";
     break;
    
  case "editlocations":
    $edit = mysql_query("SELECT * FROM locations WHERE id_locations='$_GET[id]'");
    $r    = mysql_fetch_array($edit);

    echo "<h2>Edit Lokasi Institusi</h2>
	      <div style='opacity: 0.7; position: absolute; top: 298px; left: 338px; display: none;' class='tooltip'></div>
          <form id='myform' method=POST enctype='multipart/form-data' action=$aksi?module=locations&act=update>
          <input type=hidden name=id value=$r[id_locations]>
          <table width=100% style='border: 1pt dashed #CCC; padding: 10px; background-color:#FFFFCC;'>
		  
          <tr><td width=120>Nama Id Object </td>     <td> : <input type=text name='judul' size=60 value='$r[judul]'  title='Isikan nama / identitas Instansi.'></td></tr>
          <tr><td>Nama Objek</td>  <td> : <select name='kategori' title='Apabila kategori tidak diubah, biarkan saja..'>";
 
          $tampil=mysql_query("SELECT * FROM kategori ORDER BY nama_kategori");
          if ($r[id_kategori]==0){
            echo "<option value=0 selected>- Pilih Kategori -</option>";
          }   

          while($w=mysql_fetch_array($tampil)){
            if ($r[id_kategori]==$w[id_kategori]){
              echo "<option value=$w[id_kategori] selected>$w[nama_kategori]</option>";
            }
            else{
              echo "<option value=$w[id_kategori]>$w[nama_kategori]</option>";
            }
          }
    echo "</select></td></tr>";

 echo"<tr><td><b>Kordinat</b></td><td>: <input name=lat type=text id='lat' title='Latitude Terisi Jika Peta Ditekan' size='25' value='$r[latitude]' />&nbsp; &nbsp; <input name=long id='long' type=text title='Longitude Terisi Jika Peta Ditekan' size='25' value='$r[longitude]'/></td></tr>
			  <tr><td><b>Lokasi</b></td><td> : <input name=address id='address' type=text title='Alamat Otomatis Terisi Jika Peta Ditekan' size='70' value='$r[address]' /></td></tr>";

echo"<tr><td>Kondisi</td>     <td> : <input type=text name='nobangunan' value='$r[nobangunan]' title='Masukan Nomor Bangunan' size=10></td></tr>";
echo"<tr><td>Keberadaan</td>     <td> : <input type=text name='telepon' value='$r[telepon]' title='Masukan Nomor telepon' size=10></td></tr>";
echo"<tr><td>Tahun Anggaran</td>     <td> : <input type=text name='kodepos' value='$r[kodepos]' title='Masukan Nomor kode pos' size=10></td></tr>";

          echo "<tr><td>Keterangan</td>   <td> <textarea name='description' title='Lama Sewa berdasarkan bulan / tahun.' style='width: 550px; height: 320px; '>$r[description]</textarea></td></tr>
          <tr><td>Gambar 1</td>       <td> ";
          if ($r[gambar]!=''){
              echo "<a id='galeri' href='../foto_locations/$r[gambar]' title='$r[address]' ><img src='../foto_locations/small_$r[gambar]'  width='150' style='border: none; background-color: #fff; padding: 2px; margin: 3px 3px 3px 3px; border: 1px solid #0066B3; float: left; -moz-border-radius:4px;	-webkit-border-radius:4px;'>";  
          }
    echo "</td></tr>
          <tr><td>Ganti Gambar</td>    <td> : <input type=file name='fupload' title='Apabila gambar tidak diubah, dikosongkan saja.'size=30></td></tr>
          <tr><td colspan=2> </td></tr>
		  
<tr><td>Gambar 2</td>       <td> ";
      if ($r[gambar2]!=''){
              echo "<a id='galeri' href='../foto_locations/$r[gambar2]' title='$r[address]' ><img src='../foto_locations/small_$r[gambar2]'  width='150' style='border: none; background-color: #fff; padding: 2px; margin: 3px 3px 3px 3px; border: 1px solid #0066B3; float: left; -moz-border-radius:4px;	-webkit-border-radius:4px;'>";  
          }
    echo "</td></tr>
          <tr><td>Ganti Lambang</td>    <td> : <input type=file name='fupload2' title='Apabila lambang tidak diubah, dikosongkan saja.'size=30></td></tr>
          <tr><td colspan=2> </td></tr>";
 
    echo  "<tr><td colspan=2><input type=submit value=Update>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
}
?>
