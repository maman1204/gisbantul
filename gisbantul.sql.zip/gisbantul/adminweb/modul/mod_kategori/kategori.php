<?php
$aksi="modul/mod_kategori/aksi_kategori.php";
switch($_GET[act]){
  // Tampil Kategori
  default:
    echo "<h2>Kategori Institusi</h2>
          <input type=button value='Tambah Kategori Institusi' onclick=\"window.location.href='?module=kategori&act=tambahkategori';\">
          <table style='border: 1pt dashed #999999; padding: 10px;'>
          <tr><th>no</th><th>nama kategori</th><th>status</th><th>aksi</th></tr>"; 
    $tampil=mysql_query("SELECT * FROM kategori ORDER BY id_kategori DESC");
    $no=1;
    while ($r=mysql_fetch_array($tampil)){
       echo "<tr><td>$no</td>
             <td>$r[nama_kategori]</td>
             <td align=center>$r[aktif]</td>
             <td><a href=?module=kategori&act=editkategori&id=$r[id_kategori]>Edit</a>
             </td></tr>";
      $no++;
    }
    echo "</table>";
    echo "<div id=paging>*) Data pada Kategori tidak bisa dihapus, tapi bisa di non-aktifkan melalui Edit Kategori.</div><br>";
    break;
  
  // Form Tambah Kategori
  case "tambahkategori":
    echo "<h2>Tambah Kategori Institusi</h2>
          <form method=POST enctype='multipart/form-data' action='$aksi?module=kategori&act=input' >
          <table width=100% style='border: 1pt dashed #999999; padding: 10px; '>
          <tr><td>Nama Kategori</td><td> : <input type=text name='nama_kategori'></td></tr>
		  <tr><td>Icon</td>      <td> : <input type=file name='fupload' size=40> <br/>
                                          <br>&nbsp; Tipe icon harus PNG dan ukuran lebar maks: 40 pixel. <br/>&nbsp; Nama file icon harus sama dengan nama kategori.</td></tr>";

    
    echo "<tr><td colspan=2><input type=submit name=submit value=Simpan>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
     break;
  
  // Form Edit Kategori  
  case "editkategori":
    $edit=mysql_query("SELECT * FROM kategori WHERE id_kategori='$_GET[id]'");
    $r=mysql_fetch_array($edit);

    echo "<h2>Edit Kategori Institusi</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=kategori&act=update>
          <input type=hidden name=id value='$r[id_kategori]'>
          <table width=100% style='border: 1pt dashed #999999; padding: 10px; '>
          <tr><td>Nama Kategori</td><td> : <input type=text name='nama_kategori' value='$r[nama_kategori]'></td></tr>";
    if ($r[aktif]=='Y'){
      echo "<tr><td>Aktif</td> <td> : <input type=radio name='aktif' value='Y' checked>Y  
                                      <input type=radio name='aktif' value='N'> N</td></tr>";
    }
    else{
      echo "<tr><td>Aktif</td> <td> : <input type=radio name='aktif' value='Y'>Y  
                                      <input type=radio name='aktif' value='N' checked>N</td></tr>";
    }
echo"<tr><td>Icon</td>       <td>  ";
          if ($r[jenis]!=''){
              echo "<img src='../icon/$r[jenis]'>";  
          }
 echo "</td></tr>
          <tr><td>Ganti Icon</td>    <td> : <input type=file name='fupload' size=30> *) Apabila gambar tidak diubah, dikosongkan saja.<br/><br/>&nbsp; Tipe gambar harus PNG dan ukuran lebar maks: 40 pixel. <br/>&nbsp; Nama file gambar harus sama dengan nama kategori.</td></tr>
          <tr><td colspan=2></td></tr>";
    echo "<tr><td colspan=2><input type=submit value=Update>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
    break;  
}
?>
