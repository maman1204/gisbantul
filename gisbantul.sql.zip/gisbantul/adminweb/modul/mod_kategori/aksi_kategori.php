<?php
error_reporting(0);
include "../../../config/koneksi.php";
include "../../../config/fungsi_seo.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET[module];
$act=$_GET[act];

// Input kategori
if ($module=='kategori' AND $act=='input'){


   $lokasi_file = $_FILES['fupload']['tmp_name'];
  $nama_file   = $_FILES['fupload']['name'];
  
  $nama_kategori = $_POST['nama_kategori'];
$kategori_seo = seo_title($_POST['nama_kategori']);
  // Apabila ada gambar yang diupload
if (!empty($lokasi_file)){
    UploadIcon($nama_file);
  move_uploaded_file($lokasi_file,"icon/$nama_file");
  mysql_query("INSERT INTO kategori(nama_kategori,
                                     kategori_seo,
									 jenis)
									 VALUES('$_POST[nama_kategori]',
									         '$kategori_seo',
											 '$nama_file')");
}
  else{ 										
    mysql_query("INSERT INTO kategori(nama_kategori,
                                     kategori_seo)
									 VALUES('$_POST[nama_kategori]',
									         '$kategori_seo')");
	} 
  header('location:../../media.php?module='.$module);
}

// Update kategori
elseif ($module=='kategori' AND $act=='update'){


   $lokasi_file = $_FILES['fupload']['tmp_name'];
  $nama_file   = $_FILES['fupload']['name'];
  
   $kategori_seo = seo_title($_POST['nama_kategori']);

  // Apabila gambar tidak diganti
  if (empty($lokasi_file)){
 
  mysql_query("UPDATE kategori SET nama_kategori  ='$_POST[nama_kategori]', 
                                  kategori_seo    ='$kategori_seo', 
								  aktif           ='$_POST[aktif]' 
               WHERE id_kategori = '$_POST[id]'");
}
  else{
    UploadIcon($nama_file);
	move_uploaded_file($lokasi_file,"icon/$nama_file");
	 mysql_query("UPDATE kategori SET nama_kategori ='$_POST[nama_kategori]', 
                                  kategori_seo      ='$kategori_seo', 
								  aktif             ='$_POST[aktif]',
								  jenis             ='$nama_file' 
               WHERE id_kategori = '$_POST[id]'");
}
  header('location:../../media.php?module='.$module);
}
?>
