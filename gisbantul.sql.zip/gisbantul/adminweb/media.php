<?php
session_start();
error_reporting(0);
ob_start();	
include "../config/koneksi.php";
               
if (empty($_SESSION[username]) AND empty($_SESSION[passuser])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=index.php><b>LOGIN</b></a></center>";
 
  
}
else{
?>

<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script language="javascript" type="text/javascript"
src="../tinymcpuk/tiny_mce_src.js"></script>
<script type="text/javascript">
tinyMCE.init({
		mode : "textareas",
		theme : "advanced",
		plugins : "table,youtube,advhr,advimage,advlink,emotions,flash,searchreplace,paste,directionality,noneditable,contextmenu",
		theme_advanced_buttons1_add : "fontselect,fontsizeselect",
		theme_advanced_buttons2_add : "separator,preview,zoom,separator,forecolor,backcolor,liststyle",
		theme_advanced_buttons2_add_before: "cut,copy,paste,separator,search,replace,separator",
		theme_advanced_buttons3_add_before : "tablecontrols,separator,youtube,separator",
		theme_advanced_buttons3_add : "emotions,flash",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		extended_valid_elements : "hr[class|width|size|noshade]",
		file_browser_callback : "fileBrowserCallBack",
		paste_use_dialog : false,
		theme_advanced_resizing : true,
		theme_advanced_resize_horizontal : false,
		theme_advanced_link_targets : "_something=My somthing;_something2=My somthing2;_something3=My somthing3;",
		apply_source_formatting : true
});

	function fileBrowserCallBack(field_name, url, type, win) {
		var connector = "../../filemanager/browser.html?Connector=connectors/php/connector.php";
		var enableAutoTypeSelection = true;
		
		var cType;
		tinymcpuk_field = field_name;
		tinymcpuk = win;
		
		switch (type) {
			case "image":
				cType = "Image";
				break;
			case "flash":
				cType = "Flash";
				break;
			case "file":
				cType = "File";
				break;
		}
		
		if (enableAutoTypeSelection && cType) {
			connector += "&Type=" + cType;
		}
		
		window.open(connector, "tinymcpuk", "modal,width=600,height=400");
	}
</script>
<link href="style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="../js/jquery-1.3.1.min.js"></script>
<script type="text/javascript" src="../js/jquery-1.4.3.min.js"></script>
<script type="text/javascript">

$(document).ready(function() {	


  //Get all the LI from the #tabMenu UL
  $('#tabMenu li').click(function(){
    
    //perform the actions when it's not selected
    if (!$(this).hasClass('selected')) {    
           
	    //remove the selected class from all LI    
	    $('#tabMenu li').removeClass('selected');
	    
	    //Reassign the LI
	    $(this).addClass('selected');
	    
	    //Hide all the DIV in .boxBody
	    $('.boxBody div.parent').slideUp('1500');
	    
	    //Look for the right DIV in boxBody according to the Navigation UL index, therefore, the arrangement is very important.
	    $('.boxBody div.parent:eq(' + $('#tabMenu > li').index(this) + ')').slideDown('1500');
	    
	 }
    
  }).mouseover(function() {

    //Add and remove class, Personally I dont think this is the right way to do it, anyone please suggest    
    $(this).addClass('mouseover');
    $(this).removeClass('mouseout');   
    
  }).mouseout(function() {
    
    //Add and remove class
    $(this).addClass('mouseout');
    $(this).removeClass('mouseover');    
    
  });

	//Mouseover with animate Effect for Category menu list
  $('.boxBody #category li').click(function(){

    //Get the Anchor tag href under the LI
    window.location = $(this).children().attr('href');
  }).mouseover(function() {

    //Change background color and animate the padding
    $(this).css('backgroundColor','#888');
    $(this).children().animate({paddingLeft:"20px"}, {queue:false, duration:300});
  }).mouseout(function() {
    
    //Change background color and animate the padding
    $(this).css('backgroundColor','');
    $(this).children().animate({paddingLeft:"0"}, {queue:false, duration:300});
  });  
	
	//Mouseover effect for Posts, Comments, Famous Posts and Random Posts menu list.
  $('#.boxBody li').click(function(){
    window.location = $(this).children().attr('href');
  }).mouseover(function() {
    $(this).css('backgroundColor','#888');
  }).mouseout(function() {
    $(this).css('backgroundColor','');
  });  	
	
});

</script>
<script src="../js/tabsmap.js" type="text/javascript"></script>
<script>

// memeriksa apakah pengguna menyediakan semua data untuk menambahkan lokasi baru
function check()
{
	if (document.getElementById('lat').value == "" || document.getElementById('long').value == "" || document.getElementById('address').value == "")
	{
		alert("Click on the map to choose location!");
		return false;
	}
	
if (document.getElementById('id_locations').value == "")
	{
		alert("Write a name for the new location!");
		return false;
	}
	
	if (document.getElementById('judul_seo').value == "")
	{
		alert("Write a description for the new location!");
		return false;
	}
	
	if (document.getElementById('judul').value == "")
	{
		alert("Write a name for the new location!");
		return false;
	}
	
	if (document.getElementById('description').value == "")
	{
		alert("Write a description for the new location!");
		return false;
	}
	
	
	if (document.getElementById('nama_instansi').value == "")
	{
		alert("Write a nama pemilik for the new location!");
		return false;
	}
	
	if (document.getElementById('no_telp').value == "")
	{
		alert("Write a nomor pemilik for the new location!");
		return false;
	}
	
	if (document.getElementById('user_name').value == "")
	{
		alert("Write your name!");
		return false;
	}
	
	if (document.getElementById('user_location').value == "")
	{
		alert("Write your location!");
		return false;
	}
	
	if (document.getElementById('gambar').value == "")
	{
		alert("Choose a gambar for the new location!");
		return false;
	}
	
	if (document.getElementById('jenis').value == "")
	{
		alert("Choose a gambar for the new location!");
		return false;
	}

</script>

<script type="text/javascript" src="http://maps.google.com/maps/api/js?key=AIzaSyBHDgTgLQShXW2W32kojOEbehp2Vo8w1XY&callback=initMap"></script>
<script type="text/javascript">
	
	
var geocoder;
	var map;

function initialize()
	{
		// define map center
		var natuna = new google.maps.LatLng(-7.887762,110.327358);
		
		// define map options
		var myOptions = 
		{
			zoom: 14,
			center: natuna,
			mapTypeId: google.maps.MapTypeId.HYBRID,
			mapTypeId: google.maps.MapTypeId.ROADMAP,
			
		};
		
		// initialize map
		map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
		
		// menambahkan pendengar acara ketika pengguna mengklik pada peta
		google.maps.event.addListener(map, 'click', function(event) {
			findAddress(event.latLng);
		});
	}
	
	// menemukan alamat untuk lokasi yang diberikan
	function findAddress(loc)
	{
		geocoder = new google.maps.Geocoder(); 
		
		if (geocoder) 
		{
			geocoder.geocode({'latLng': loc}, function(results, status) 
			{
				if (status == google.maps.GeocoderStatus.OK) 
				{
					if (results[0]) 
					{
						address = results[0].formatted_address;
						
						// fill in the results in the form
						document.getElementById('lat').value = loc.lat();
						document.getElementById('long').value = loc.lng();
						document.getElementById('address').value = address;
					}
				} 
				else 
				{
					alert("Geocoder failed due to: " + status);
				}
			});
		}
	}
	
	// initialize the array of markers
	var markers = new Array();
	
	// fungsi yang menambahkan spidol untuk peta
	function addMarkers()
	{
		// get the values for the markers from the hidden elements in the form
        var ids = document.getElementById('ids').value;
		var juds = document.getElementById('juds').value;
		var lats = document.getElementById('lats').value;
		var lngs = document.getElementById('lngs').value;
		var addresses = document.getElementById('addresses').value;
		var names = document.getElementById('names').value;
		var descrs = document.getElementById('descrs').value;
		var luasbs = document.getElementById('luasbs').value;
		var hargas = document.getElementById('hargas').value;
		var namals = document.getElementById('namals').value;
		var nops = document.getElementById('nops').value;
		var gambars = document.getElementById('gambars').value;
		var user_names = document.getElementById('user_names').value;
		var user_locs = document.getElementById('user_locs').value;
		var jens = document.getElementById('jens').value;
	
        var is  = ids.split(";;")
		var jds = juds.split(";;")
		var las = lats.split(";;")
		var lgs = lngs.split(";;")
		var ads = addresses.split(";;")
		var nms = names.split(";;")
		var dss = descrs.split(";;")
		var lsb = luasbs.split(";;")
		var hrg = hargas.split(";;")
		var nml = namals.split(";;")
		var nop = nops.split(";;")
		var gbr = gambars.split(";;")
		var usrn = user_names.split(";;")
		var usrl = user_locs.split(";;")
		var jns  = jens.split(";;")
	
		
		
		// untuk setiap lokasi, membuat penanda baru dan infowindow untuk itu
		for (i=0; i<las.length; i++)
		{
			if (las[i] != "")
			{
				// add marker	
				set_icon(jns[i]);			
				var loc = new google.maps.LatLng(las[i],lgs[i]);
				var marker = new google.maps.Marker({
					position: loc, 
					map: window.map,
					icon: gambar_tanda,
					title: nms[i]
					
				});
				
				
				
				
				markers[i] = marker;
				
				var contentString = [
				
  				// buat tooltips tabs
				  '<div id="tabsview">',
					'<div id="tab1" class="tab_sel" onClick="javascript: displayPanel(1);" align="center">&nbsp; Photo &nbsp;</div>',
					'<div id="tab2" class="tab" style="margin-left: 1px;" onClick="javascript: displayPanel(2);" align="center">&nbsp; Informasi &nbsp;</div>',
					'<div id="tab3" class="tab" style="margin-left: 1px;" onClick="javascript: displayPanel(3);" align="center">&nbsp; Lokasi &nbsp;</div>',
				  '</div>',
				  
				'<div class="tab_bdr">','</div>',
				// tampilan tabs 1
				  '<div class="panel" id="panel1" style="display: block;">',
				  '<span>',
				  '<ul>',				      				  
					  '<table>',
				    
					'<tr>',
					  '<td align="left">','<a id="galeri" href="../foto_locations/'+gbr[i]+'" title='+nms[i]+'>','<img src="../foto_locations/small_'+gbr[i]+'"/>'+'</a>',
					  
					  '</td>','</tr>',
					  '</table>',
					  
				  '</ul>',
				  '</span>',
				  '</div>',
				  // tampilan tabs 2
				  '<div class="panel" id="panel2" style="display: none;">',
				  '<span>',
				  '<ul>',
      			      '<table width=240>',
				    '<tr>',
					  '<td colspan="2" align="center" bgcolor="#CCCCCC" valign="middle" height="30">',
					  '<b>'+nms[i]+'</a>'+
					 
					  '</b>','</td>','</tr>',
					'<tr>',
					  '<td width=95 valign="top">','<b>Nama Id Object</b>','</td>','<td align="left">: '+jds[i]+' m<br/>'+
					  '</td>','</tr>',
					
					'<tr>',
					  
					  '<td valign="top">','<b>Telephone</b>','</td>','<td align="left">: '+nop[i]+'<br/>'+
					  '</td>','</tr>',
					'<tr>',
					  '<td colspan="2" valign="buttom" height="35">',
					 
					 
					  '</td>','</tr>',
					  '</table>',
				  '</ul>',
				  '</span>',
				  '</div>',
				  // tampilan tabs 3
				  '<div class="panel" id="panel3" style="display: none;">',
				  '<span>',
				  '<ul>',
				    '<table width=240>',
				    '<tr>',
					  '<td valign="left">','<b>Alamat</b>','</td>',
					  '</tr>',
					  '<tr>',
					  '<td align="left">'+ads[i]+'<p>'+
					  '</td>','</tr>',
					'<tr>',
					  '<td valign="left">','<b>Kordinat</b>','</td>',
					  '</tr>',
					  '<td align="left">'+loc+'<p>'+
					  '</td>','</tr>',
					  '<tr>',
					  '<td colspan="2">',
					
					 
					  '</td>','</tr>',
					  '</table>',
				  '</ul>',
				  '</span>',
				  '</div>',
				  
				// akhir tampilan tabs
				].join('');
				
				var infowindow = new google.maps.InfoWindow;
				
				bindInfoWindow(marker, window.map, infowindow, contentString);
			}
		}
	}
	
	// membuat sambungan antara jendela info dan penanda (jendela info yang muncul ketika pengguna pergi dengan mouse di atas penanda)
	function bindInfoWindow(marker, map, infoWindow, contentString)
	{
		google.maps.event.addListener(marker, 'click', function() {
			
			map.setCenter(marker.getPosition());
			
			infoWindow.setContent(contentString);
			infoWindow.open(map, marker);
			$("#tabs").tabs();
		 });
		 
	}
	
function set_icon(jenisnya){
     switch(jenisnya){
        case "cermin.png":
            gambar_tanda = '../icon/cermin.png';
            break;
        case "petunjuk.png":
            gambar_tanda = '../icon/petunjuk.png';
            break;
        case  "perintah.png":
            gambar_tanda = '../icon/perintah.png';
            break;
		case  "peringatan.png":
            gambar_tanda = '../icon/peringatan.png';
            break;
		case  "larangan.png":
            gambar_tanda = '../icon/larangan.png';
            break;
		case  "apill.png":
            gambar_tanda = '../icon/apill.png';
            break;
        case  "atcs.png":
            gambar_tanda = '../icon/atcs.png';
            break;
        case  "cone.png":
            gambar_tanda = '../icon/cone.png';
            break;
        case  "guardrill.png":
            gambar_tanda = '../icon/guardrill.png';
            break;
        case  "kantor.png":
            gambar_tanda = '../icon/kantor.png';
            break;
        case  "warning.png":
            gambar_tanda = '../icon/warning.png';
            break;
        case  "zoss.png":
            gambar_tanda = '../icon/zoss.png';
            break;
        case  "drk.png":
            gambar_tanda = '../icon/drk.png';
            break;
        case  "lpju.png":
            gambar_tanda = '../icon/lpju.png';
            break;
        case  "terminal.png":
            gambar_tanda = '../icon/terminal.png';
            break;
case  "halte.png":
            gambar_tanda = '../icon/halte.png';
            break;
case  "plc.png":
            gambar_tanda = '../icon/plc.png';
            break;
case  "drk1.png":
            gambar_tanda = '..icon/drk1.png';
            break;
    }
	
}


</script>




	  
<script src="../js/clock.js" type="text/javascript"></script>



    <script type="text/javascript"> 
      $(document).ready(function(){
      	$("ul.tabs").tabs("div.panes > div");
	    });
	</script>




<script src="../js/jquery-1.4.3.min.js" type="text/javascript"></script>
<script type="text/javascript" src="../js/jquery.tools.min.js"></script>

    <script type="text/javascript"> 
      $(document).ready(function(){
        // pilih semua input dan terapkan tooltip pada semua input 
        $("#myforms :input").tooltip({
        
        // letakkan posisi tooltip di bagian/sebelah kanan
	      position: "center right",

	      // mengatur letak posisi berdasarkan koordinat
        offset: [-2, 10],

	     // pakai efek fade (memudar perlahan-lahan)
	     effect: "fade",

    	// setting ketajaman objek
	    opacity: 0.7,

	   // gunakan elemen tooltip 
	   tip: '.tooltip'
     });
	  });
	  </script>
      

<script src="../js/jquery-1.4.2.min.js" type="text/javascript"></script>
<script src="../js/jquery.validateadmin.js" type="text/javascript"></script>
<script type="text/javascript">
$().ready(function() {
	$("#myform").validate({
		rules: {
			id_locations: {
				required: true,
				minlength: 6
			},
			judul: {
				required: true,
				judul: true
			},
		

			long: {
				required: true,
				long: true
			},
			address: {
				required: true,
				address: true
			},
			
			agree: "required"
		},
		messages: {
			id_locations: {
				required: "Masukkan username",
				minlength: "Id minimal 6 karakter"
			},
			judul: {
				required: "Masukkan judul",
				judul: "judul tidak valid"
			},
			long: {
				required: "Masukkan latitude dan longitude",
				long: "latitude dan longitude tidak valid"
			},
			address: {
				required: "Masukkan alamat",
				address: "alamat tidak valid"
			},
			
			agree: "Pastikan anda setuju"
		}
		
	});
	

});


</script>

<script src="../js/jquery.fancybox.js" type="text/javascript"></script>
<script src="../js/jquery.mousewheel.js" type="text/javascript"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$("a#galeri").fancybox({
				'titlePosition'	: 'inside'
			});
		});
  </script>
  
<script type="text/javascript" src="../js/jquery-1.4.3.min.js"></script>
<script src="../js/ddaccordion.js" type="text/javascript"></script>

<script type="text/javascript">


ddaccordion.init({
	headerclass: "submenuheader", //Shared CSS class name of headers group
	contentclass: "submenu", //Shared CSS class name of contents group
	revealtype: "click", //Reveal content when user clicks or onmouseover the header? Valid value: "click", "clickgo", or "mouseover"
	mouseoverdelay: 400, //if revealtype="mouseover", set delay in milliseconds before header expands onMouseover
	collapseprev: true, //Collapse previous content (so only one open at any time)? true/false 
	defaultexpanded: [], //index of content(s) open by default [index1, index2, etc] [] denotes no content
	onemustopen: false, //Specify whether at least one header should be open always (so never all headers closed)
	animatedefault: false, //Should contents open by default be animated into view?
	persiststate: true, //persist state of opened contents within browser session?
	toggleclass: ["", ""], //Two CSS classes to be applied to the header when it's collapsed and expanded, respectively ["class1", "class2"]
	
	animatespeed: "fast", //speed of animation: integer in milliseconds (ie: 200), or keywords "fast", "normal", or "slow"
	oninit:function(headers, expandedindices){ //custom code to run when headers have initalized
		//do nothing
	},
	onopenclose:function(header, index, state, isuseractivated){ //custom code to run whenever a header is opened or closed
		//do nothing
	}
})


</script>


</head>

<body onLoad="initialize(); addMarkers(); startclock()">

	<div id="container">
		<div id="wrapper">


			<!-- CONTENT -->
      <div id="content">
	<div id="content-kiri">
     
      
        <?php include "menu.php"; ?>
     
 <?php include "legenda.php"; ?>
          </div>
 	

  <div id="content-kanan">
		<?php include "content.php"; ?>
  </div>
</div><!-- end CONTENT -->

			

			<!-- FOOTER -->
			<div id="footer">
				
				<div class="foot_content">
				  <p>Dishub Kabupaten Bantul</p>
			  </div>
			</div><!-- / end footer -->
		</div><!-- / end wrapper -->
	</div>
<!-- / end container -->

</body>
</html>
<?php
}
?>

