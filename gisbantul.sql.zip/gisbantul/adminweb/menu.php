<div class="glossymenu">
<a class="menuitem" href=?module=home>&#187; Home</a>
<a class="menuitem submenuheader" href="" >&#187; Manajemen +</a>
<div class="submenu">
      <ul>
        <li></li>
        <?php
include "../config/koneksi.php";

if ($_SESSION[leveluser]=='admin'){
  $sql=mysql_query("select * from modul where aktif='Y' order by urutan");
}
else{
  $sql=mysql_query("select * from modul where status='user' and aktif='Y' order by urutan"); 
} 
while ($m=mysql_fetch_array($sql)){  
  echo "<li><a class='menuitem' href='$m[link]'>&#187; $m[nama_modul]</a></li>";
}
?>        
  </ul>
        </div>	
<a class="menuitem" href=logout.php>&#187; Logout</a>
    
	  
 </div>