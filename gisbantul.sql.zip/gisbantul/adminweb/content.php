<?php
include "../config/koneksi.php";
include "../config/library.php";
include "../config/fungsi_indotgl.php";
include "../config/fungsi_combobox.php";
include "../config/class_paging.php";

// Bagian Home
if ($_GET[module]=='home'){
  echo "<h2>Selamat Datang</h2>
          
          <p align=right>Login : $hari_ini, ";
  echo tgl_indo(date("Y m d")); 
  echo " | "; 
  echo date("H:i:s");
  echo " WIB</p>";
}

// Bagian tentang kami
elseif ($_GET[module]=='tentangkami'){
  if ($_SESSION[leveluser]=='admin'){
    include "modul/mod_tentangkami/tentangkami.php";
  }
}

// Bagian User
elseif ($_GET[module]=='user'){
  if ($_SESSION[leveluser]=='admin' OR $_SESSION[leveluser]=='user'){
    include "modul/mod_users/users.php";
  }
}

// Bagian Modul
elseif ($_GET[module]=='modul'){
  if ($_SESSION[leveluser]=='admin'){
    include "modul/mod_modul/modul.php";
  }
}

// Bagian Kategori
elseif ($_GET[module]=='kategori'){
  if ($_SESSION[leveluser]=='admin'){
    include "modul/mod_kategori/kategori.php";
  }
}

// Bagian locations
elseif ($_GET[module]=='locations'){
  if ($_SESSION[leveluser]=='admin' OR $_SESSION[leveluser]=='user'){
    include "modul/mod_locations/locations.php";  
                             
  }
}


// Bagian Hubungi Kami
elseif ($_GET[module]=='hubungi'){
  if ($_SESSION[leveluser]=='admin'){
    include "modul/mod_hubungi/hubungi.php";
  }
}

// Bagian Sekilas link
elseif ($_GET[module]=='sekilaslink'){
  if ($_SESSION[leveluser]=='admin'){
    include "modul/mod_sekilaslink/sekilaslink.php";
  }
}

// Apabila modul tidak ditemukan
else{
  echo "<p><b>MODUL BELUM ADA ATAU BELUM LENGKAP</b></p>";
}
?>
