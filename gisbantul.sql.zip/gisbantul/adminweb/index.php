<?php 
  error_reporting(0);
  ob_start();	
  session_start();
  include "../config/koneksi.php";
  include "../config/fungsi_autolink.php";
  include "../config/tgl_indo.php"; 
  include "../config/class_paging.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">




<link rel="stylesheet" href="style.css" type="text/css" />
 

<style type="text/css">
<!--
body {
	background-image: url(images/Soppeng.jpg);
}
-->
</style></head>

<body>
<div id="login">
<form name="login" action="cek_login.php" method="POST" onSubmit="return validasi(this)">
      <table>
<tr><td>Username</td><td> : <input type="text" name="username"></td></tr>
<tr><td>Password</td><td> : <input type="password" name="password"><br/></td></tr>
<tr><td colspan="2"><input type="submit" value="Login"><br/><br/>
Kembali ke halaman menu utama... <a href="../index.php">Klick disini</a></td></tr>
</table>
</form>
</div>
</body>
</html>
