
 <?php
include "../config/koneksi.php";


// Bagian Home
if ($_GET[module]=='home'){

}


// Bagian locations
elseif ($_GET[module]=='locations'){
  if ($_SESSION[leveluser]=='admin' OR $_SESSION[leveluser]=='user'){
    

 switch($_GET[act]){
  // Tampil locations
  default:
  echo"<h2> LEGENDA</h2>";
    $tampil=mysql_query("SELECT nama_kategori, kategori.id_kategori, kategori_seo, jenis,  
                                         COUNT(locations.id_kategori) AS jml 
                                         FROM kategori LEFT JOIN locations 
                                         ON locations.id_kategori=kategori.id_kategori 
                                         WHERE kategori.aktif='Y'  
                                         GROUP BY nama_kategori");

    while ($r=mysql_fetch_array($tampil)){

	echo"	<img src='../icon/$r[jenis]' width='30' height='36'>";echo"<label> $r[nama_kategori]</label></br> ";
    }

 
   echo"<div class='petakecil'>
				<img src='../images/peta lampung.png' border='0' />
				</div>
        <div class='matangin'>
				<img src='../images/matangin.png' border='0' />
				</div><br/>";
 
    break;
	          

    
				}
				                             
  }
}

?>
 