<?php
  header('location:/gisbantul');
?> 
