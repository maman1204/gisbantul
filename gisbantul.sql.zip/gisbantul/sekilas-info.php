
 <?php
include "../config/koneksi.php";
// Bagian Home
if ($_GET[module]=='home'){
echo"<div id='legenda'>";
    $tampil=mysql_query("SELECT nama_kategori, kategori.id_kategori, kategori_seo, jenis,  
                                         COUNT(locations.id_kategori) AS jml 
                                         FROM kategori LEFT JOIN locations 
                                         ON locations.id_kategori=kategori.id_kategori 
                                         WHERE kategori.aktif='Y'  
                                         GROUP BY nama_kategori");

    while ($r=mysql_fetch_array($tampil)){

	echo"<img src='icon/$r[jenis]' width='30' height='36'>";
	echo"<label><a href=kategori-$r[id_kategori].html><b>~ $r[nama_kategori]</b></a>&nbsp;($r[jml])</label></br> ";
    }

    
   echo"<img src='images/peta lampung.png' border='0' />
		<img src='images/matangin.png' border='0' />";
		//include "shoutbox.php";
				echo"</div>";
				
	include "kanan.php";
}

// Bagian locations
elseif ($_GET[module]=='detaillocations'){
 
 switch($_GET[act]){
  // Tampil locations
  default:
  echo"<h2>Sekilas Link</h2>";
  echo"<ul id='listticker'>";

           
              $sekilas=mysql_query("SELECT * FROM sekilaslink ORDER BY id_link DESC LIMIT 5");
              while($s=mysql_fetch_array($sekilas)){
                echo "<li><a href=$s[url]> <span class='news-text'>$s[nama_link]</span><a></li>";
              }
          
          echo"</ul>";
		  
echo"<div id='legenda'>";


    $tampil=mysql_query("SELECT nama_kategori, kategori.id_kategori, kategori_seo, jenis,  
                                         COUNT(locations.id_kategori) AS jml 
                                         FROM kategori LEFT JOIN locations 
                                         ON locations.id_kategori=kategori.id_kategori 
                                         WHERE kategori.aktif='Y'  
                                         GROUP BY nama_kategori");

    while ($r=mysql_fetch_array($tampil)){

	echo"<img src='icon/$r[jenis]' width='30' height='36'>";
	echo"<label><a href=kategori-$r[id_kategori].html><b>~ $r[nama_kategori]</b></a>&nbsp;($r[jml])</label></br> ";
    }

    echo"<div id='directions'></div>";
   echo"<img src='images/peta lampung.png' border='0' />
		<img src='images/matangin.png' border='0' />";
				echo"</div>";
				
				include "kanan.php";
    break;
		}
				                             
  }

// Modul locations per kategori
elseif ($_GET[module]=='detailkategori'){
	  echo"<h2>Sekilas Link</h2>";
echo"<ul id='listticker'>";
            
            
              $sekilas=mysql_query("SELECT * FROM locations ORDER BY id_locations");
              while($s=mysql_fetch_array($sekilas)){
                echo "<li><span class='news-text'><a href=locations-$s[id_locations]-$s[judul_seo].html>$s[judul]</a></span></li>";
              }
         
          echo" </ul>";         
}


// Modul hubungi kami
elseif ($_GET[module]=='hubungikami'){
	echo "</br></br></br><table>";
	echo"<tr><td colspan=2><img src= 'images/admin.png' border='0' /></td></br>";
	echo"<tr><td><strong>Email</strong></td><td>: <strong>dishubkabbantul@gmail.com</strong></td>";
	echo"<tr><td><strong>Nama</strong></td><td>: <strong>Administrator</strong></td>";
	echo"<tr><td><strong>Jabatan</strong></td><td>: <strong>Super Administrator</strong></td>";
	echo"<tr><td></td><td><br/></td>";
	echo"<tr><td colspan=2>Hubungi kami secara online dengan mengisi form samping kiri ini:</td>";
	echo "</table>";       
	include "kanan.php";     
}




?>
 