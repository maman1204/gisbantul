<?php
 if ($_GET[module]=='home'){ ?>
			<!-- CONTENT -->
	<div id="content">         
        <p><p>Selamat Datang di <b>Sistem Informasi Geografis </b>Dinas Perhubungan Kabupaten Bantul</br></br>
		<div class="pencarian">
			<form method="POST" id="searchform" action="hasil-pencarian.html"> <!-- form pencarian -->
				<input class="searchField" type="text" name="kata" maxlength="50" value="Pencarian..." onblur="if(this.value=='') this.value='Pencarian...';" onfocus="if(this.value=='Pencarian...') this.value='';" />
				<input class="searchSubmit" type="submit" value="" />
			</form>
		</div>
		<div id='map_canvas' style="width:690px;  height:500px; border:solid #6633FF 1.5px; float:left; -moz-border-radius:6px;"></div>
		<?php
		$locations = mysql_query("SELECT * FROM locations,users,kategori WHERE kategori.id_kategori=locations.id_kategori");
			while ($locat = mysql_fetch_array($locations)){
			    $ids .= $locat['id_locations'].";;";
				$juds .= $locat['judul_seo'].";;";
				$lats .= $locat['latitude'].";;";
				$lngs .= $locat['longitude'].";;";
				$addresses .= $locat['address'].";;";
				$names .= $locat['judul'].";;";
				$descrs .= $locat['description'].";;";
				$nops .= $locat['telepon'].";;";
				$gambars .= $locat['gambar'].";;";
				$jens .= $locat['jenis'].";;";
				$i++;
			}			
            echo" 
			<input type=hidden value='$ids;' id='ids' name='ids'/>
			<input type=hidden value='$juds;' id='juds' name='juds'/>
			<input type=hidden value='$lats;' id='lats' name='lats'/>
			<input type=hidden value='$lngs;' id='lngs' name='lngs'/>
			<input type=hidden value='$addresses;' id='addresses' name='addresses'/>
			<input type=hidden value='$names;' id='names' name='names'/>
			<input type=hidden value='$descrs;' id='descrs' name='descrs'/>
			<input type=hidden value='$nops;' id='nops' name='nops'/>
			<input type=hidden value='$gambars;' id='gambars' name='gambars'/>
			<input type=hidden value='$jens;' id='jens' name='jens'/>";
        ?>
	</div> <!-- / end content -->
<?php 
} elseif ($_GET[module]=='detaillocations'){
	echo "<div id='content'>          
           <div id='content-detail'>";            

	$detail=mysql_query("SELECT * FROM locations,users,kategori   
                      WHERE users.username=locations.username 
                      AND kategori.id_kategori=locations.id_kategori
                      AND id_locations='$_GET[id]'");
	
	
	$d   = mysql_fetch_array($detail);
	$tgl = tgl_indo($d[tanggal]);
	$baca = $d[dibaca]+1;
	
	// add lcoation data to info strings
            
			    $ids .= $d['id_locations'].";;";
				$juds .= $d['judul_seo'].";;";
				$lats .= $d['latitude'].";;";
				$lngs .= $d['longitude'].";;";
				$addresses .= $d['address'].";;";
				$names .= $d['judul'].";;";
				$descrs .= $d['description'].";;";
				$nops .= $d['telepon'].";;";
				$gambars .= $d['gambar'].";;";
				$jens .= $d['jenis'].";;";

	 echo"  
			<input type=hidden value='$ids;' id='ids' name='ids'/>
			<input type=hidden value='$juds;' id='juds' name='juds'/>
			<input type=hidden value='$lats;' id='lats' name='lats'/>
			<input type=hidden value='$lngs;' id='lngs' name='lngs'/>
			<input type=hidden value='$addresses;' id='addresses' name='addresses'/>
			<input type=hidden value='$names;' id='names' name='names'/>
			<input type=hidden value='$descrs;' id='descrs' name='descrs'/>
			<input type=hidden value='$nops;' id='nops' name='nops'/>
			<input type=hidden value='$gambars;' id='gambars' name='gambars'/>
			<input type=hidden value='$jens;' id='jens' name='jens'/>";
	
	   echo "<span class=tanggal>$d[hari], $tgl - $d[jam] WIB</span><br />";
	echo "<span class=judul>$d[judul]</span><br />";
  // Apabila ada gambar dalam locations, tampilkan   
 	if ($d[gambar]!='cici'){
		
	}
	echo "<table width=100% >
	<tr><td rowspan='6' width=164><a id='galeri' href='foto_locations/$d[gambar]' title='$d[judul]'><img src='foto_locations/$d[gambar]' width='164' height='164' border=0></td>
	<tr><td width=120>Nama Id Object</td><td>: $d[judul]</td></tr>
	<tr><td>Lokasi</td><td>: $d[address]</td></tr>
	<tr><td>Kondisi</td><td>: $d[nobangunan]</td></tr>
	<tr><td>Tahun Anggaran</td><td>: $d[kodepos]</td></tr>
	<tr><td>Keberadaan</td><td>: $d[telepon]</td></tr>
	<tr><td rowspan='2' width=164 valign=top><span class=image><a id='galeri' href='foto_locations/$d[gambar2]' title='$d[judul]'><img src='foto_locations/$d[gambar2]' width='164' height='164' border=0></span></td>
	<tr><td colspan='3'>$d[description]</td></tr>
	</table><br/>";
  	 
  // Apabila detail locations dilihat, maka tambahkan berapa kali dibacanya
	mysql_query("UPDATE locations SET dibaca=$d[dibaca]+1 WHERE id_locations='$_GET[id]'"); 
		echo"<div id='map_canvas' style='width:700px; height:400px; border:solid #6633FF 2.5px; -moz-border-radius:6px;'></div>";
		echo"<div style='opacity: 0.7; position: absolute; top: 298px; left: 338px; display: none;' class='tooltip'></div>
		<form id='myform' method=POST>
				<br />
				<input name=lat type='hidden' id='lat' size='25' readonly/><input name=long id='long' type='hidden' size='25' readonly/>
				Lokasi Anda <input name=address id='address' type=text title=' Klik Pada map jika ingin menentukan lokasi anda.' size='70' readonly/>
				<input type='hidden' id='to' value='$d[address]' />			
				<input type='hidden' id='mode' value='DRIVING' />					
				<input type='button' value='Tampilkan Jalur' id='driveit' title=' Klik tombol ini untuk mencari.' />
			</form>";
		echo "Kategori: <a href=kategori-$d[id_kategori].html><b>$d[nama_kategori]</b></a> 
        - Dibaca: <b>$baca</b> kali</span><br />
		<span class=posting>Diposting oleh : <b>$d[nama_instansi]</b> ";
		echo "</div>
    </div>";            
}

// Modul locations per kategori
elseif ($_GET[module]=='detailkategori'){
	echo "<div id='content'>          
           <div id='content-detail'>";            
  // Tampilkan nama kategori
  $sq = mysql_query("SELECT nama_kategori from kategori where id_kategori='$_GET[id]'");
  $n = mysql_fetch_array($sq);
  
  
  echo "<span class=judul_head>&#187; Kategori : <b>$n[nama_kategori]</b></span><br /><br />";
   
  
   $p      = new Paging3;
  $batas  = 4;
  $posisi = $p->cariPosisi($batas);
  // Tampilkan daftar locations sesuai dengan kategori yang dipilih
 	$sql   = "SELECT * FROM locations WHERE id_kategori='$_GET[id]' 
            ORDER BY id_locations DESC LIMIT $posisi,$batas";		 

	$hasil = mysql_query($sql);
	$jumlah = mysql_num_rows($hasil);
	// Apabila ditemukan locations dalam kategori
	if ($jumlah > 0){
   while($r=mysql_fetch_array($hasil)){
		$tgl = tgl_indo($r[tanggal]);
		
	
	// show the location name in the right of the map with link that calls the highlightMarker function
			
		
		echo "<br />";
		
 		// Apabila ada gambar dalam locations, tampilkan
    if ($r[gambar]!=''){

echo"<form>
<div><label><a id='galeri' href='foto_locations/$r[gambar]' title='$r[judul]'><img src='foto_locations/$r[gambar]' width='111' border=0></a></label><br/>
<span class=judul><a href=locations-$r[id_locations]-$r[judul_seo].html>$r[judul]</a></span>
</div>
</form>";
			
		}
     
	
	 }
	
  $jmldata     = mysql_num_rows(mysql_query("SELECT * FROM locations WHERE id_kategori='$_GET[id]'"));
  $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
  $linkHalaman = $p->navHalaman($_GET[halkategori], $jmlhalaman);

  echo "<br/><br/><br/><br/><br/><br/><br/>Hal: $linkHalaman";
  
	
  }
  else{
    echo "Belum ada locations pada kategori ini.";
  }
  
  echo "</div>
    </div>";            
} elseif ($_GET[module]=='hasilcari'){ 
?>
	<div id='contenthasil'>
        <div id='content-detail-hasil'>
        	<div class="tombol">
        		<a class="savepdf button" id="print" href="#" onclick="printContent('HTMLtoPDF')">Print</a>
				<a href="#" class="savepdf button" id="btnExport3" onClick ="$('#HTMLtoPDF').tableExport({type:'excel',escape:'false'});">XLS</a>
				
        	</div>
		<?php
		$kata = trim($_POST[kata]);
		$pisah_kata = explode(" ",$kata);
		$jml_katakan = (integer)count($pisah_kata);
		$jml_kata = $jml_katakan-1;
		$cari = "SELECT * FROM locations WHERE ";
		for ($i=0; $i<=$jml_kata; $i++){
			$cari .= "judul LIKE '%$pisah_kata[$i]%' OR description LIKE '%$pisah_kata[$i]%' OR address LIKE '%$pisah_kata[$i]%' OR nobangunan LIKE '%$pisah_kata[$i]%' OR telepon LIKE '%$pisah_kata[$i]%' OR kodepos LIKE '%$pisah_kata[$i]%' OR latitude LIKE '%$pisah_kata[$i]%' OR longitude LIKE '%$pisah_kata[$i]%'";
			if ($i < $jml_kata ){
				$cari .= " OR ";
			}
		}	
		$batas  = 100000000;
		$cari .= "ORDER BY id_locations DESC LIMIT 0,$batas";
		$hasil  = mysql_query($cari);
		$ketemu = mysql_num_rows($hasil);
		if ($ketemu > 0){
			$d   = mysql_fetch_array($detail);

			echo '<div class="pencarian">';
			echo '<form method="POST" id="searchform" action="hasil-pencarian.html">';
			echo '<input class="searchField" type="text" name="kata" maxlength="50" placeholder ="Cari..." value="" />';
			echo '<input class="searchSubmit" type="submit" value="" />';
			echo '</form>';
			echo '</div>';
			echo "<div id='HTMLtoPDF' class='savepdf'>";
			echo "<span class='judul_head'><b>Hasil Pencarian</b></span><br />";
			echo "<p>Ditemukan <b>$ketemu</b> locations dengan kata <b>$kata</b> : </p>"; 
			echo "<table id='divid' style='background-color:#FFFFCC;padding: 0px 10px;width=100%;float: left; width: 100%;'>";
			echo "<tr class='headerPrint'>
					<th id='hdconJudul'>Judul</th>
					<th id='hdconDeskripsi'>Deskripsi</th>
					<th id='hdconLokasi'>Lokasi</th>
					<th id='hdconKoordinat'>Koordinat</th>
					<th id='hdconKeberadaan'>Keberadaan</th>
					<th id='hdconKondisi'>Kondisi</th>
					<th id='hdconTahunAnggaran'>Tahun Anggaran</th>
				</tr>";
			
			while($t=mysql_fetch_array($hasil)){
				echo "<tr class='contentPrint'>";
				echo "<td id='judulku'><a href=locations-$t[id_locations]-$t[judul_seo].html>$t[judul]</a></td>";
				echo "<td id='deskripsikonten'>$t[description]</td>";
				echo "<td id='address'>$t[address]</td>";
				echo "<td id='koordinat'>$t[latitude] <br> $t[longitude]</td>";
				echo "<td id='telepon'>$t[telepon]</td>";
				echo "<td id='nobangunan'>$t[nobangunan]</td>";
				echo "<td id='kodepos'>$t[kodepos]</td>";
				echo "</tr>";
			}
			echo "</table></div>";		
		} else {
			echo "<span class='judul_head'><b>Hasil Pencarian</b></span><br />";
			echo "Tidak ditemukan lokasi dengan kata <b>$kata</b><br><br>";
			echo '<div class="pencarian">';
			echo '<form method="POST" id="searchform" action="hasil-pencarian.html">';
			echo '<input class="searchField" type="text" name="kata" maxlength="50" value="" placeholder="Cari Lagi..."/>';
			echo '<input class="searchSubmit" type="submit" value="" />';
			echo '</form>';
			echo '</div>';
		}
		?>
		</div>
	</div>
<?php 
} elseif ($_GET[module]=='tentangkamikami'){
  echo "<div id='content'>          
          <div id='content-detail'>";
  echo "<span class=judul_head>&#187; <b>Tentang Sistem Informasi Geografis Dishub Kabupaten Bantul</b></span><br /><br />"; 

	$tentangkami = mysql_query("SELECT * FROM modul WHERE id_modul='63'");
	$r      = mysql_fetch_array($tentangkami);

  echo "<table width=100% ><tr><td class=isi>";
  if ($r[gambar]!=''){
		echo "<a id='galeri' href='foto_banner/$r[gambar]'><img src='foto_banner/$r[gambar]' width='164' height='144' border=0></a>";
	}
	$isi_tentangkami=nl2br($r[static_content]);
  echo "$isi_tentangkami </td></tr>"; 
  echo"</table>";
  echo "</div>
    </div>";            
}



// Modul semua locations
elseif ($_GET[module]=='semualocations'){
  echo "<div id='content'>          
          <div id='content-detail'>";
  echo "<span class=judul_head>&#187; <b>Tampil Semua Bangunan</b></span><br /><br />"; 
  $p      = new Paging2;
  $batas  = 12;
  $posisi = $p->cariPosisi($batas);
  // Tampilkan semua locations
  $sql=mysql_query("select count(komentar.id_komentar) as jml, judul, judul_seo, jam, 
                       locations.id_locations, hari, tanggal, gambar, description    
                       from locations left join komentar 
                       on locations.id_locations=komentar.id_locations
                       and aktif='Y' 
                       group by locations.id_locations DESC LIMIT $posisi,$batas");
  while($r=mysql_fetch_array($sql)){
		$tgl = tgl_indo($r[tanggal]);
		echo "<table><tr><td>
          <span class=tanggal>$r[hari], $tgl - $r[jam] WIB</span><br />";
 		echo "<span class=judul><a href=locations-$r[id_locations]-$r[judul_seo].html>$r[judul]</a></span><br />";
			// Apabila ada gambar dalam locations, tampilkan
    if ($r[gambar]!=''){
			echo "<a id='galeri' href='foto_locations/$r[gambar]' title='$r[judul]'><img src='foto_locations/$r[gambar]' width='55' border=0></a><p>";
			
		}
      // Tampilkan hanya sebagian isi locations
      $description = htmlentities(strip_tags($r[description])); // membuat paragraf pada isi locations dan mengabaikan tag html
      $isi = substr($description,0,220); // ambil sebanyak 150 karakter
      $isi = substr($description,0,strrpos($isi," ")); // potong per spasi kalimat

      echo "$isi ... <a href=locations-$r[id_locations]-$r[judul_seo].html>Selengkapnya</a> (<b>$r[jml] komentar</b>)
            </td></tr></table>
            <hr color=#CCC noshade=noshade />";
	 }
	
  $jmldata     = mysql_num_rows(mysql_query("SELECT * FROM locations"));
  $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
  $linkHalaman = $p->navHalaman($_GET[hallocations], $jmlhalaman);

  echo "Hal: $linkHalaman <br /><br />";
  echo "</div>
    </div>";            
}


// Modul hubungi kami
elseif ($_GET[module]=='hubungikami'){
  echo "<div id='content'>          
          <div id='content-detail'>";
  echo "<span class=judul_head>&#187; <b>Hubungi Kami</b></span><br /><br />"; 
  echo "<b>Hubungi kami secara online dengan mengisi form dibawah ini:</b>
  
		<!-- tooltip -->
      <div style='opacity: 0.7; position: absolute; top: 298px; left: 338px; display: none;' class='tooltip'></div>
        
		<form id='myform' action=hubungi-aksi.html method=POST>
        <h3>Hubungi Kami</h3><p>
        <div id='inputs'>
          <label for='nama'>Nama Lengkap</label>
		      <input name='nama' size='25' title='Masukan nama lengkap anda yang asli' /> <br/>
						
      		
			<label for='subjek'>Subjek</label>
		      <input name='subjek' size='25' title='Subjek harus sesuai dengan tema' /><br/>
			  <label for='email'>Email</label>
		      <input name='email' size='35' title='Email harus mengandung karakter titik (.) dan @.' /><br/>
			
            <label for='pesan'>Pesan</label>
			<textarea name='pesan'  style='width: 300px; height: 100px;' title='Masukan pesan yang ingin anda sampaikan kepada kami'></textarea><br/>
		     
      		  <label></label><img src='captcha.php'><br/>
		      <label></label><input type='text' name='kode' size='10' maxlength='6' title='masukan semua kode captha yang ada di atas.' /><br />
	     </div>
	    <p><button type='submit' name='submit' value='Kirim' title='Klik tombol untuk proses data'>Proses</button></p>
      </form>";

  echo "</div>
    </div>";            
}


// Modul hubungi aksi
elseif ($_GET[module]=='hubungiaksi'){
  echo "<div id='content'>          
          <div id='content-detail'>";

$nama=trim($_POST[nama]);
$email=trim($_POST[email]);
$subjek=trim($_POST[subjek]);
$pesan=trim($_POST[pesan]);

if (empty($nama)){
  echo "Anda belum mengisikan NAMA<br />
  	      <a href=javascript:history.go(-1)><b>Ulangi Lagi</b>";
}
elseif (empty($email)){
  echo "Anda belum mengisikan EMAIL<br />
  	      <a href=javascript:history.go(-1)><b>Ulangi Lagi</b>";
}
elseif (empty($subjek)){
  echo "Anda belum mengisikan SUBJEK<br />
  	      <a href=javascript:history.go(-1)><b>Ulangi Lagi</b>";
}
elseif (empty($pesan)){
  echo "Anda belum mengisikan PESAN<br />
  	      <a href=javascript:history.go(-1)><b>Ulangi Lagi</b>";
}
else{
	if(!empty($_POST['kode'])){
		if($_POST['kode']==$_SESSION['captcha_session']){

  mysql_query("INSERT INTO hubungi(nama,
                                   email,
                                   subjek,
                                   pesan,
                                   tanggal) 
                        VALUES('$_POST[nama]',
                               '$_POST[email]',
                               '$_POST[subjek]',
                               '$_POST[pesan]',
                               '$tgl_sekarang')");
  echo "<span class=posting>&#187; <b>Hubungi Kami</b></span><br /><br />"; 
  echo "<p align=center><b>Terimakasih telah menghubungi kami. <br /> Kami akan segera meresponnya.</b></p>";
		}else{
			echo "Kode yang Anda masukkan tidak cocok<br />
			      <a href=javascript:history.go(-1)><b>Ulangi Lagi</b></a>";
		}
	}else{
		echo "Anda belum memasukkan kode<br />
  	      <a href=javascript:history.go(-1)><b>Ulangi Lagi</b></a>";
	}
}
  echo "</div>
    </div>";            
}
     ?>

