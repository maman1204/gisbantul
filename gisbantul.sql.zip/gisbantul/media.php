<?php 
  error_reporting(0);
  ob_start();	
  session_start();
    
  include "config/koneksi.php";
  include "config/fungsi_autolink.php";
  include "config/fungsi_badword.php";
  include "config/tgl_indo.php"; 
  include "config/class_paging.php";

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<title><?php include "dina_titel.php"; ?></title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="index, follow">
<meta name="description" content="<?php include "dina_meta1.php"; ?>">

<meta http-equiv="Copyright" content="bangkit">
<meta name="author" content="bangkit">
<meta http-equiv="imagetoolbar" content="no">
<meta name="language" content="Indonesia">
<meta name="revisit-after" content="7">
<meta name="webcrawlers" content="all">
<meta name="rating" content="general">
<meta name="spiders" content="all">

<link rel="stylesheet" href="css/style.css" type="text/css" />
<script>
function printContent(el){
	var restorepage = document.body.innerHTML;
	var printContent =document.getElementById(el).innerHTML;
	document.body.innerHTML = printContent;
	window.print();
	document.body.innerHTML = restorepage;

}
</script>
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="plugin/tableExport.js"></script>
<script type="text/javascript" src="plugin/jquery.base64.js"></script>


<script type="text/javascript">
$(document).ready(function() {	


  //Get all the LI from the #tabMenu UL
  $('#tabMenu li').click(function(){
    
    //perform the actions when it's not selected
    if (!$(this).hasClass('selected')) {    
           
	    //remove the selected class from all LI    
	    $('#tabMenu li').removeClass('selected');
	    
	    //Reassign the LI
	    $(this).addClass('selected');
	    
	    //Hide all the DIV in .boxBody
	    $('.boxBody div.parent').slideUp('1500');
	    
	    //Look for the right DIV in boxBody according to the Navigation UL index, therefore, the arrangement is very important.
	    $('.boxBody div.parent:eq(' + $('#tabMenu > li').index(this) + ')').slideDown('1500');
	    
	 }
    
  }).mouseover(function() {

    //Add and remove class, Personally I dont think this is the right way to do it, anyone please suggest    
    $(this).addClass('mouseover');
    $(this).removeClass('mouseout');   
    
  }).mouseout(function() {
    
    //Add and remove class
    $(this).addClass('mouseout');
    $(this).removeClass('mouseover');    
    
  });

	//Mouseover with animate Effect for Category menu list
  $('.boxBody #category li').click(function(){

    //Get the Anchor tag href under the LI
    window.location = $(this).children().attr('href');
  }).mouseover(function() {

    //Change background color and animate the padding
    $(this).css('backgroundColor','#888');
    $(this).children().animate({paddingLeft:"20px"}, {queue:false, duration:300});
  }).mouseout(function() {
    
    //Change background color and animate the padding
    $(this).css('backgroundColor','');
    $(this).children().animate({paddingLeft:"0"}, {queue:false, duration:300});
  });  
	
	//Mouseover effect for Posts, Comments, Famous Posts and Random Posts menu list.
  $('#.boxBody li').click(function(){
    window.location = $(this).children().attr('href');
  }).mouseover(function() {
    $(this).css('backgroundColor','#888');
  }).mouseout(function() {
    $(this).css('backgroundColor','');
  });  	
	
});

</script>




<script>

// memeriksa apakah pengguna menyediakan semua data untuk menambahkan lokasi baru
function check()
{
	if (document.getElementById('lat').value == "" || document.getElementById('long').value == "" || document.getElementById('address').value == "")
	{
		alert("Click on the map to choose location!");
		return false;
	}
	
if (document.getElementById('id_locations').value == "")
	{
		alert("Write a name for the new location!");
		return false;
	}
	
	if (document.getElementById('judul_seo').value == "")
	{
		alert("Write a description for the new location!");
		return false;
	}
	
	if (document.getElementById('judul').value == "")
	{
		alert("Write a name for the new location!");
		return false;
	}
	
	if (document.getElementById('description').value == "")
	{
		alert("Write a description for the new location!");
		return false;
	}
	

	if (document.getElementById('telepon').value == "")
	{
		alert("Write a nomor pemilik for the new location!");
		return false;
	}
	

	if (document.getElementById('gambar').value == "")
	{
		alert("Choose a gambar for the new location!");
		return false;
	}


</script>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyBHDgTgLQShXW2W32kojOEbehp2Vo8w1XY&callback=initMap"></script>
<script type="text/javascript">
	
	
var geocoder;
var map;

var directionsDisplay = new google.maps.DirectionsRenderer();
var directionsService = new google.maps.DirectionsService();

function initialize()
	{

		// define map center
		var natuna = new google.maps.LatLng(-7.887762,110.327358);
		
		// define map options
		var myOptions = {
			zoom: 14,
			center: natuna,

			mapTypeId: google.maps.MapTypeId.ROADMAP,
			
		};
	
	
		// initialize map
		map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
		// menambahkan pendengar acara ketika pengguna mengklik pada peta
		google.maps.event.addListener(map, 'click', function(event) {
			findAddress(event.latLng);
		});
		
		}

	// menemukan alamat untuk lokasi yang diberikan
	function findAddress(loc)
	{
		geocoder = new google.maps.Geocoder(); 
		
		if (geocoder) 
		{
			geocoder.geocode({'latLng': loc}, function(results, status) 
			{
				if (status == google.maps.GeocoderStatus.OK) 
				{
					if (results[0]) 
					{
						address = results[0].formatted_address;
						
						// fill in the results in the form
						document.getElementById('lat').value = loc.lat();
						document.getElementById('long').value = loc.lng();
						document.getElementById('address').value = address;
					}
				} 
				else 
				{
					alert("Geocoder failed due to: " + status);
				}
			});
		}
	}
	
	
	
	// initialize the array of markers
	var markers = new Array();
	
	// fungsi yang menambahkan spidol untuk peta
	function addMarkers()
	{
		// get the values for the markers from the hidden elements in the form
        var ids = document.getElementById('ids').value;
		var juds = document.getElementById('juds').value;
		var lats = document.getElementById('lats').value;
		var lngs = document.getElementById('lngs').value;
		var addresses = document.getElementById('addresses').value;
		var names = document.getElementById('names').value;
		var descrs = document.getElementById('descrs').value;
		var nops = document.getElementById('nops').value;
		var gambars = document.getElementById('gambars').value;
		var jens = document.getElementById('jens').value;
	
        var is  = ids.split(";;")
		var jds = juds.split(";;")
		var las = lats.split(";;")
		var lgs = lngs.split(";;")
		var ads = addresses.split(";;")
		var nms = names.split(";;")
		var dss = descrs.split(";;")
		var nop = nops.split(";;")
		var gbr = gambars.split(";;")
		var jns  = jens.split(";;")
	
		
		
		// untuk setiap lokasi, membuat penanda baru dan infowindow untuk itu
		for (i=0; i<las.length; i++)
		{
			if (las[i] != "")
			{
				// add marker	
				set_icon(jns[i]);			
				var loc = new google.maps.LatLng(las[i],lgs[i]);
				var marker = new google.maps.Marker({
					position: loc, 
					map: window.map,
					icon: gambar_tanda,
					title: nms[i]
					
				});
			
				
				markers[i] = marker;
				
				var contentString = [
				
  				// buat tooltips tabs
				  '<div id="tabsview">',
					'<div id="tab1" class="tab_sel" onClick="javascript: displayPanel(1);" align="center">&nbsp; Photo &nbsp;</div>',
					'<div id="tab2" class="tab" style="margin-left: 1px;" onClick="javascript: displayPanel(2);" align="center">&nbsp; Informasi &nbsp;</div>',
					'<div id="tab3" class="tab" style="margin-left: 1px;" onClick="javascript: displayPanel(3);" align="center">&nbsp; Lokasi &nbsp;</div>',
				  '</div>',
				  
				'<div class="tab_bdr">','</div>',
				// tampilan tabs 1
				  '<div class="panel" id="panel1" style="display: block;">',
				  '<span>',
				  '<ul>',				      				  
					  '<table>',
				    
					'<tr>',
					  '<td align="left">','<a id="galeri" href="foto_locations/'+gbr[i]+'" title='+nms[i]+'>','<img src="foto_locations/small_'+gbr[i]+'"/>'+'</a>',
					  
					  '</td>','</tr>',
					  '</table>',
					  
				  '</ul>',
				  '</span>',
				  '</div>',
				  // tampilan tabs 2
				  '<div class="panel" id="panel2" style="display: none;">',
				  '<span>',
				  '<ul>',
      			      '<table width=240>',
				    '<tr>',
					  '<td colspan="2" align="center" bgcolor="#CCCCCC" valign="middle" height="30">',
					  '<b>','<a href=locations-'+is[i]+'-'+jds[i]+'.html>' +nms[i]+'</a>'+
					 
					  '</b>','</td>','</tr>',
					
					  '<td valign="top">','<b>Keberadaan</b>','</td>','<td align="left">: '+nop[i]+'<br/>'+
					  '</td>','</tr>',

					'<tr>',
					  '<td colspan="2" valign="buttom" height="35">',
					  '<a href=locations-'+is[i]+'-'+jds[i]+'.html>',' . . . Info Selengkapnya','</a>'+
					 
					  '</td>','</tr>',
					  '</table>',
				  '</ul>',
				  '</span>',
				  '</div>',
				  // tampilan tabs 3
				  '<div class="panel" id="panel3" style="display: none;">',
				  '<span>',
				  '<ul>',
				    '<table width=240>',
				    '<tr>',
					  '<td valign="left">','<b>Lokasi</b>','</td>',
					  '</tr>',
					  '<tr>',
					  '<td align="left">'+ads[i]+'<p>'+
					  '</td>','</tr>',
					'<tr>',
					  '<td valign="left">','<b>Kordinat</b>','</td>',
					  '</tr>',
					  '<td align="left">'+loc+'<p>'+
					  '</td>','</tr>',
					  '<tr>',
					  '<td colspan="2">',
					  '<a href=locations-'+is[i]+'-'+jds[i]+'.html>',' . . . Info Selengkapnya','</a>'+
					 
					  '</td>','</tr>',
					  '</table>',
				  '</ul>',
				  '</span>',
				  '</div>',
				  
				// akhir tampilan tabs
				  
				].join('');
				
				var infowindow = new google.maps.InfoWindow;
				
				bindInfoWindow(marker, window.map, infowindow, contentString);
			}
		}
	}
	
	// membuat sambungan antara jendela info dan penanda (jendela info yang muncul ketika pengguna pergi dengan mouse di atas penanda)
	function bindInfoWindow(marker, map, infoWindow, contentString)
	{
		google.maps.event.addListener(marker, 'click', function() {
			
			map.setCenter(marker.getPosition());
			
			infoWindow.setContent(contentString);
			infoWindow.open(map, marker);
			$("#tabs").tabs();
		 });
		 
	}


function set_icon(jenisnya){
    switch(jenisnya){
        case "cermin.png":
            gambar_tanda = 'icon/cermin.png';
            break;
        case "petunjuk.png":
            gambar_tanda = 'icon/petunjuk.png';
            break;
        case  "peringatan.png":
            gambar_tanda = 'icon/peringatan.png';
            break;
		case  "perintah.png":
            gambar_tanda = 'icon/perintah.png';
            break;
		case  "larangan.png":
            gambar_tanda = 'icon/larangan.png';
            break;
		case  "apill.png":
            gambar_tanda = 'icon/apill.png';
            break;
        case  "atcs.png":
            gambar_tanda = 'icon/atcs.png';
            break;
        case  "cone.png":
            gambar_tanda = 'icon/cone.png';
            break;
        case  "guardrill.png":
            gambar_tanda = 'icon/guardrill.png';
            break;
        case  "kantor.png":
            gambar_tanda = 'icon/kantor.png';
            break;
        case  "warning.png":
            gambar_tanda = 'icon/warning.png';
            break;
        case  "zoss.png":
            gambar_tanda = 'icon/zoss.png';
            break;
        case  "drk.png":
            gambar_tanda = 'icon/drk.png';
            break;
        case  "lpju.png":
            gambar_tanda = 'icon/lpju.png';
            break;
        case  "terminal.png":
            gambar_tanda = 'icon/terminal.png';
            break;
		case  "halte.png":
            gambar_tanda = 'icon/halte.png';
            break;
		case  "plc.png":
            gambar_tanda = 'icon/plc.png';
            break;

case  "parking.png":
            gambar_tanda = 'icon/parking.png';
            break;
case  "pita.png":
            gambar_tanda = 'icon/pita.png';
            break;
case  "zebracross.png":
            gambar_tanda = 'icon/zebracross.png';
            break;
case  "drk1.png":
            gambar_tanda = 'icon/drk1.png';
            break;

    }
}

	jQuery(document).ready(function(){		
	/*Function for creating the roadmap*/
			function calcRoute(start, end, mode) {
				var request = {
					origin:start,
					destination:end,
					travelMode: google.maps.TravelMode[mode]
				};
				directionsService.route(request, function(result, status) {
					if (status == google.maps.DirectionsStatus.OK) {
						directionsDisplay.setDirections(result);
					}
				});
				
				directionsDisplay.setMap(map);

				/*Show directions panel*/
				directionsDisplay.setPanel(document.getElementById("directions"));
			}
			
			jQuery('#driveit').click(function(){
			
			
				var srcAddr = jQuery('#address').val();
				var destAddr = jQuery('#to').val();
				var mode = jQuery('#mode').val();
				calcRoute(srcAddr, destAddr, mode);
			});
	
				
	});

</script>
<script src="js/newsticker.js" type="text/javascript"></script>
<script src="js/tabsmap.js" type="text/javascript"></script>
<script type="text/javascript"> 
    $(document).ready(function(){
        $("#myform :input").tooltip({
			position: "center right",
			offset: [-2, 10],
			effect: "fade",
			opacity: 0.7,
			tip: '.tooltip'
		});
	});
</script>

<script type="text/javascript"> 
    $(document).ready(function(){
      	$("ul.tabs").tabs("div.panes > div");
	});
</script>
<script src="js/clock.js" type="text/javascript"></script>
</head>

<body onload="startclock(); initialize(); addMarkers()">
	<div id="container">
		<div id="wrapper">
			<!-- HEADER -->
			<div id="header">
				<div class="intro"><span  id='date' style='font-size: 13px color: yellow' style='color: yellow'></span> , <span id='clock' style='font-size: 13px'></span> Wib
					<div class="rssicon">
						<img src="images/rss.png" border="0" /> <!-- icon rss -->
					</div>
				</div> <!-- / intro -->		
                 <!-- MENU -->
				<ul class="nav">
				<?php function get_menu($data, $parent = 0) {
					static $i = 1;
					$tab = str_repeat(" ", $i);
					if ($data[$parent]) {
						$html = "$tab<ul id='menu'>";
						$i++;
						foreach ($data[$parent] as $v) {
							$child = get_menu($data, $v->id);
							$html .= "$tab<li>";
							$html .= '<a href="'.$v->url.'">'.$v->judul.'</a>';
							if ($child) {
								$i--;
								$html .= $child;
								$html .= "$tab";
							}
							$html .= '</li>';
						}
						$html .= "$tab</ul>";
						return $html;
					} else {
						return false;
					}
				}
				$result = mysql_query("SELECT * FROM menu ORDER BY menu_order");
				while ($row = mysql_fetch_object($result)) {
					$data[$row->parent_id][] = $row;
				}
				$menu = get_menu($data);
				echo "$menu"; ?>
			</ul>
			<!-- / End Menu -->		
			</div> <!-- /header -->
			<!-- CONTENT -->
		<?php include "kiri.php"; ?>
		<div id="sidebar-kanan">
           <?php include "sekilas-info.php"; ?>    
        </div> <!-- sidebar kanan-->

			<!-- FOOTER -->
			<div id="footer">
				<div id="social_nav_horizontal">
					<ul id="sosial-link">
						<li><a class="facebook" href="http://www.facebook.com/sharer.php?u=http://gis.perhubungan.bantul.go.id"  title="Share this on Facebook" >Facebook</a></li>
						<li><a class="twitter" href="http://twitter.com/home?status=Gis Dishub Bantul Title- http://gis.perhubungan.bantul.go.id@TwitterUserName" title="Tweet This Page" >Twitter</a></li>
					</ul>
				</div>
			</div><!-- / end footer -->
		</div><!-- / end wrapper -->
	</div><!-- / end container -->
<script type="text/javascript" src="plugin/html2canvas.min.js"></script>
<script type="text/javascript" src="js/app.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.debug.js"></script>
<script type="text/javascript" src="js/jspdf.min.js"></script>
</body>
</html>
