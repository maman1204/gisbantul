<?php
$server = "fdb18.awardspace.net";
$username = "2669932_gisbantul";
$password = "maman1204";
$database = "2669932_gisbantul";

// Koneksi dan memilih database di server
mysql_connect($server,$username,$password) or die("Koneksi gagal");
mysql_select_db($database) or die("Database tidak bisa dibuka");
?>
