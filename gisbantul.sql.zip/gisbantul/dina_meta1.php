<?php
$sql = mysql_query("select judul from locations where id_locations='$_GET[id]'");
$j   = mysql_fetch_array($sql);

if (ISSET($_GET[id])){
		echo "$j[judul]";
}
else{
		echo "GIS Kabupaten Bantul.";
}
?>
