(function(){
var 
	div = $('#HTMLtoPDF'),
	cache_width = div.width(),
	a4  =[800,1200];  // for a4 size paper width and height

$('#create_pdf').on('click',function(){
	$('body').scrollTop(0);
	createPDF();
});
//create pdf
function createPDF(){
	getCanvas().then(function(canvas){
		var img = canvas.toDataURL("image/png"),
		doc = new jsPDF({
          unit:'px', 
          filter:'a4', 
        }); 
		doc.setProperties({
        title: 'Gis Madiun',
        creator: 'Gis Madiun'
		});		
        doc.addImage(img, 'JPEG',0,0);
        doc.save('gismadiun.pdf');
        div.width(cache_width);
	});
}

// create canvas object
function getCanvas(){
	div.width((a4[1]*0.96000) -10).css('width','780');
	return html2canvas(div,{
    	imageTimeout:2000,
    	removeContainer:true
    });	
}

}());