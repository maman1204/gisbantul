-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Waktu pembuatan: 24. Maret 2018 jam 21:25
-- Versi Server: 5.1.41
-- Versi PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gisbantul`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `hubungi`
--

CREATE TABLE IF NOT EXISTS `hubungi` (
  `id_hubungi` int(5) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `subjek` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `pesan` text COLLATE latin1_general_ci NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id_hubungi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=17 ;

--
-- Dumping data untuk tabel `hubungi`
--

INSERT INTO `hubungi` (`id_hubungi`, `nama`, `email`, `subjek`, `pesan`, `tanggal`) VALUES
(4, 'Arif Budiman', 'arifbudimanaaa123@gmail.com', 'Request Code', '', '2018-05-25'),
(15, 'ETA', 'echa_cici@yahoo.co.id', 'penjelasan', 'Love u', '0000-00-00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id_kategori` int(5) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `kategori_seo` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `jenis` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id_kategori`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=54 ;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`, `kategori_seo`, `jenis`, `aktif`) VALUES
(2, 'Cermin Tikungan', 'cermin-tikungan', 'cermin.png', 'Y'),
(19, 'Rambu Petunjuk', 'rambu-petunjuk', 'petunjuk.png', 'Y'),
(21, 'Rambu Perintah', 'rambu-perintah', 'perintah.png', 'Y'),
(22, 'Rambu Peringatan', 'rambu-peringatan', 'peringatan.png', 'Y'),
(23, 'Rambu Larangan', 'rambu-larangan', 'larangan.png', 'Y'),
(36, 'APILL', 'apill', 'apill.png', 'Y'),
(37, 'ATCS', 'atcs', 'atcs.png', 'N'),
(38, 'Cone', 'cone', 'cone.png', 'N'),
(39, 'Guardrill', 'guardrill', 'guardrill.png', 'Y'),
(40, 'Kantor', 'kantor', 'kantor.png', 'Y'),
(41, 'Warning Light', 'warning-light', 'warning.png', 'Y'),
(42, 'Zoss', 'zoss', 'zoss.png', 'Y'),
(43, 'DRK', 'drk', 'drk.png', 'Y'),
(44, 'LPJU', 'lpju', 'lpju.png', 'Y'),
(45, 'Terminal', 'terminal', 'terminal.png', 'N'),
(46, 'Halte', 'halte', 'halte.png', 'Y'),
(47, 'Pelican', 'pelican', 'plc.png', 'N'),
(53, 'Pita Penggaduh', 'pita-penggaduh', 'pita.png', 'Y'),
(52, 'Parkir Area', 'parkir-area', 'parking.png', 'Y'),
(51, 'Zebra Cross', 'zebra-cross', 'zebracross.png', 'Y'),
(30, 'Hazard', 'hazard', 'drk1.png', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `locations`
--

CREATE TABLE IF NOT EXISTS `locations` (
  `id_locations` int(10) NOT NULL AUTO_INCREMENT,
  `id_kategori` int(5) NOT NULL,
  `username` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `judul` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `judul_seo` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci NOT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `address` varchar(145) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `nobangunan` varchar(12) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `telepon` varchar(15) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `kodepos` varchar(15) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `hari` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `gambar` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `gambar2` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `dibaca` int(5) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_locations`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=DYNAMIC AUTO_INCREMENT=1609 ;

--
-- Dumping data untuk tabel `locations`
--

INSERT INTO `locations` (`id_locations`, `id_kategori`, `username`, `judul`, `judul_seo`, `description`, `latitude`, `longitude`, `address`, `nobangunan`, `telepon`, `kodepos`, `hari`, `tanggal`, `jam`, `gambar`, `gambar2`, `dibaca`) VALUES
(1608, 30, 'maman', 'Hazard Sisi Jalan', 'hazard-sisi-jalan', '', -7.83821, 110.36445, '', '', '', '', 'Jumat', '2018-03-23', '15:24:33', '66inspeksi25.jpg', '34', 1),
(1604, 44, 'maman', 'Lampu Penerangan Jalan Umu', 'lampu-penerangan-jalan-umu', '', -7.83784, 110.36461, '', '', 'Terpasang', '', 'Rabu', '2018-03-21', '15:13:18', '', '', 1),
(1605, 23, 'maman', 'Rambu Larangan Berjalan Terus karena Wajib Memberi Prioritas Kepada Arus Lalu Lintas dari Arah yang ', 'rambu-larangan-berjalan-terus-karena-wajib-memberi-prioritas-kepada-arus-lalu-lintas-dari-arah-yang-', '', -7.83822, 110.36445, '', '', 'Kebutuhan', '', 'Rabu', '2018-03-21', '16:01:55', '55IMG_9136.JPG', '91', 1),
(1603, 44, 'maman', 'Lampu Penerangan Jalan Umum', 'lampu-penerangan-jalan-umum', '', -7.83728, 110.3649, '', 'Baik', 'Terpasang', '', 'Selasa', '2018-03-13', '14:50:12', '', '', 1),
(1602, 23, 'maman', 'Rambu Larangan Berjalan Terus karena Wajib Memberi Prioritas Kepada Arus Lalu Lintas dari Arah yang ', 'rambu-larangan-berjalan-terus-karena-wajib-memberi-prioritas-kepada-arus-lalu-lintas-dari-arah-yang-', '', -7.83713, 110.36502, '', '', 'Kebutuhan', '', 'Selasa', '2018-03-13', '14:47:55', '46IMG_9135.JPG', '4', 1),
(1601, 19, 'maman', 'Rambu Petunjuk Lokasi Masjid', 'rambu-petunjuk-lokasi-masjid', 'Rambu tertutup oleh pepohonan, sehingga kinerja rambu tidak terlihat oleh pengguna jalan.\r\n', -7.83676, 110.36514, '', 'Baik', 'Terpasang', '', 'Selasa', '2018-03-13', '14:43:18', '88IMG_9133.JPG', '97', 1),
(1599, 44, 'maman', 'Lampu Penerangan Jalan Umum', 'lampu-penerangan-jalan-umum', '', -7.83625, 110.36539, '', 'Baik', 'Terpasang', '', 'Selasa', '2018-03-13', '14:36:15', '92IMG_9131.JPG', '47', 3),
(1600, 44, 'maman', 'Lampu Penerangan Jalan Umum', 'lampu-penerangan-jalan-umum', '', -7.83677, 110.36514, '', 'Baik', 'Terpasang', '', 'Selasa', '2018-03-13', '14:39:39', '18IMG_9134.JPG', '64', 1),
(1597, 40, 'maman', 'Dinas Perhubungan Kabupaten Bantul', 'dinas-perhubungan-kabupaten-bantul', '', -7.90484, 110.34946, '', '', '', '', 'Selasa', '2018-03-13', '11:58:06', '59IMG_9121.JPG', '31', 1),
(1598, 36, 'maman', 'APILL Simpang 4 Jl. Parangtritis dan Ringroad', 'apill-simpang-4-jl-parangtritis-dan-ringroad', '', -7.8359, 110.36555, '', 'Baik', 'Terpasang', '', 'Selasa', '2018-03-13', '14:28:49', '3IMG_9130.JPG', '9', 1),
(1594, 21, 'maman', 'Rambu Petunjuk Lokasi Terminal Kendaraan Bermotor Umum', 'rambu-petunjuk-lokasi-terminal-kendaraan-bermotor-umum', '', -8.02281178305383, 110.333042272944, '', 'Baik', 'Terpasang', '2017', 'Sabtu', '2018-02-10', '15:28:40', '9120180210_115001.jpg', '44', 3),
(1595, 22, 'maman', 'Rambu Peringatan Persimpangan Tiga Sisi Kiri', 'rambu-peringatan-persimpangan-tiga-sisi-kiri', '', -8.02247447449694, 110.331710446626, '', 'Baik', 'Terpasang', '2017', 'Sabtu', '2018-02-10', '15:31:44', '4920180210_115124.jpg', '26', 5),
(1592, 22, 'maman', 'Rambu Peringatan Banyak Pejalan Kaki', 'rambu-peringatan-banyak-pejalan-kaki', '', -8.02285295042746, 110.333620624262, '', 'Baik', 'Terpasang', '2017', 'Sabtu', '2018-02-10', '15:06:19', '8120180210_114739.jpg', '25', 4),
(1593, 21, 'maman', 'Rambu Petunjuk Lokasi Pantai', 'rambu-petunjuk-lokasi-pantai', '', -8.02282672471706, 110.333121675289, '', 'Baik', 'Terpasang', '2017', 'Sabtu', '2018-02-10', '15:14:18', '4020180210_114853.jpg', '84', 4),
(1591, 22, 'maman', 'Rambu Peringatan', 'rambu-peringatan', 'Rambu tertutup ranting pohon. Perlu penebangan pohon agar pengguna jalan dapat melihat rambu.\r\n', -8.02290739749849, 110.334134602565, '', 'Baik', 'Terpasang', '2017', 'Sabtu', '2018-02-10', '14:52:07', '3820180210_114622.jpg', '20', 7),
(1589, 22, 'maman', 'Rambu Peringatan Simpang Tiga Ke Kanan', 'rambu-peringatan-simpang-tiga-ke-kanan', '', -7.89066, 110.3522, '', 'Baik', 'Terpasang', '', 'Jumat', '2018-02-09', '21:36:29', '3820180207_165155.jpg', '17', 8);

-- --------------------------------------------------------

--
-- Struktur dari tabel `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `judul` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `url` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `menu_order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=DYNAMIC AUTO_INCREMENT=43 ;

--
-- Dumping data untuk tabel `menu`
--

INSERT INTO `menu` (`id`, `parent_id`, `judul`, `url`, `menu_order`) VALUES
(1, 0, '< Home >', 'index.php', 1),
(2, 0, '< Tentang Kami >', 'tentangkami-kami.html', 2),
(12, 0, '< Hubungi Kami >', 'hubungi-kami.html', 5),
(27, 0, '< Institusi Kewilayahan >', '', 3),
(28, 0, '< Object Dishub >', '', 4),
(30, 27, 'Kantor', 'kategori-40.html', 1),
(32, 28, 'Rambu Perintah', 'kategori-21.html', 1),
(37, 28, 'Rambu Petunjuk', 'kategori-19.html', 6),
(35, 28, 'Rambu Peringatan', 'kategori-22.html', 3),
(38, 28, 'Rambu Larangan', 'kategori-23.html', 7);

-- --------------------------------------------------------

--
-- Struktur dari tabel `modul`
--

CREATE TABLE IF NOT EXISTS `modul` (
  `id_modul` int(5) NOT NULL AUTO_INCREMENT,
  `nama_modul` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `link` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `static_content` text COLLATE latin1_general_ci NOT NULL,
  `gambar` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `publish` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  `status` enum('user','admin') COLLATE latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  `urutan` int(5) NOT NULL,
  `link_seo` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_modul`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=65 ;

--
-- Dumping data untuk tabel `modul`
--

INSERT INTO `modul` (`id_modul`, `nama_modul`, `link`, `static_content`, `gambar`, `publish`, `status`, `aktif`, `urutan`, `link_seo`) VALUES
(2, 'Manajemen User', '?module=user', '', '', 'N', 'admin', 'Y', 1, ''),
(10, 'Manajemen Modul', '?module=modul', '', '', 'N', 'admin', 'Y', 2, ''),
(40, 'Hubungi Kami', '?module=hubungi', '', '', 'Y', 'admin', 'Y', 12, 'hubungi-kami.html'),
(58, 'Input Object', '?module=locations', '', '', 'Y', 'admin', 'Y', 6, 'semua-locations.html'),
(59, 'Kategori Object', '?module=kategori', '', '', 'Y', 'admin', 'Y', 5, '""'),
(63, 'Tentang Kami', '?module=tentangkami', '<div align="justify">\r\n<font size="3">Transportasi mempunyai peranan yang sangat strategis dalam mendukung mobilitas masyarakat dan mobilitas barang. Transportasi jalan diselenggarakan dengan tujuan untuk mewujudkan lalu lintas dan angkutan jalan dengan selamat, aman, cepat, lancar, tertib, teratur, nyaman, efisien dan mampu memadukan moda transportasi lainnya serta menjangkau seluruh pelosok daratan untuk menunjang pemerataan, pertumbuhan ekonomi dan stabilitas nasional. Sejalan dengan pembangunan di Kabupaten Bantul khususnya dibidang ekonomi akan berdampak pada tumbuhnya pusat-pusat kegiatan baru dan berkembangnya pusat-pusat kegiatan yang telah ada, hal ini akan menyebabkan meningkatnya mobilitas orang, barang maupun kendaraan.</font>\r\n</div>\r\n<div align="justify">\r\n<font size="3">Dalam pengendalian dan pengaturan transportasi khususnya transportasi darat keberadaan Sistem Informasi yang terstruktur dan terpola dengan baik akan sangat membantu Pemerintah dalam hal ini Dinas Perhubungan Kabupaten Bantul. Karena dengan keberadaan sistem informasi mengenai transportasi darat akan memudahkan dalam memonitor dan manajemen transportasi darat. Kabupaten Bantul merupakan salah satu kabupaten yang ada di Provinsi Daerah Istimewa Yogyakarta yang saat ini masih terbatas sarana dan prasarana transportasinya, khususnya transportasi darat. Untuk mencapai sistem jaringan transportasi yang handal, perlu adanya inventarisasi infrastruktur transportasi yang tersedia saat ini yaitu melalui Studi Sistem Database Perlengkapan Jalan, menjadi salah satu upaya yang dapat dilakukan oleh Pemerintah Daerah Kabupaten Bantul untuk dapat memetakan kondisi eksisting infrastruktur transportasi di daerah Kabupaten, khususnya perlengkapan jalan.</font>\r\n</div>\r\n<div align="justify">\r\n<font size="3">Berdasarkan penjelasan di atas, muncul permasalahan yaitu bagaimana melakukan penyusunan database infrastruktur transportasi bidang perhubungan darat di&nbsp;</font><span style="font-size: medium">Kabupaten Bantul</span><font size="3">. Database tersebut diimplementasikan dalam bentuk sistem informasi yang mampu menyimpan berbagai data dan informasi, menampilkan informasi perlengkapan jalan secara cepat dan akurat serta dilengkapi dengan informasi secara geografis (memuat data spasial), sehingga mampu menjadi alat bantu pendukung keputusan dan atau pengambil kebijakan oleh Pemerintah Daerah&nbsp;</font><span style="font-size: medium">Kabupaten Bantul</span><font size="3">.</font>\r\n</div>\r\n<div align="justify">\r\n<font size="3">Berikut ini merupakan gambaran kegiatan dan realisasi pelayanan dari Dinas Perhubungan&nbsp;</font><span style="font-size: medium">Kabupaten Bantul</span><font size="3">&nbsp;yang turut serta dalam mendukung program dari Pemerintah yaitu melaksanakan pelayanan yang baik dan handal dalam bidang transportasi darat dengan menyediakan Database Perlengkapan Jalan berbasis Sistem Informasi Geografis guna mewujudkan transportasi yang aman, selamat, tertib dan lancar.</font><br />\r\n<font size="3">\r\n</font>\r\n</div>\r\n<br />\r\n', '181180_465926186770663_1551701293_n.jpg', 'Y', 'admin', 'Y', 3, 'tentangkami-kami.html'),
(64, 'Sekilas Links', '?module=sekilaslink', '', '', 'Y', 'admin', 'Y', 27, '""');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sekilaslink`
--

CREATE TABLE IF NOT EXISTS `sekilaslink` (
  `id_link` int(5) NOT NULL AUTO_INCREMENT,
  `nama_link` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `url` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `tgl_posting` date NOT NULL,
  PRIMARY KEY (`id_link`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=DYNAMIC AUTO_INCREMENT=14 ;

--
-- Dumping data untuk tabel `sekilaslink`
--

INSERT INTO `sekilaslink` (`id_link`, `nama_link`, `url`, `tgl_posting`) VALUES
(13, 'Dinas Perhubungan Bantul', 'http://dishub.bantulkab.go.id/', '2018-03-21');

-- --------------------------------------------------------

--
-- Struktur dari tabel `shoutbox`
--

CREATE TABLE IF NOT EXISTS `shoutbox` (
  `id_shoutbox` int(5) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `website` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `pesan` text COLLATE latin1_general_ci NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id_shoutbox`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=12 ;

--
-- Dumping data untuk tabel `shoutbox`
--

INSERT INTO `shoutbox` (`id_shoutbox`, `nama`, `website`, `pesan`, `tanggal`, `jam`, `aktif`) VALUES
(8, 'sdsa', 'sada', 'sadsa', '2013-05-16', '00:08:44', 'Y'),
(9, 'sad', 'asdas', '&lt;:D&gt;sadas\r\nsadsa', '2013-05-16', '00:09:05', 'Y'),
(10, 'faridos', 'farida@gmail.com', 'mba apill mati&lt;:D&gt;', '2017-07-27', '09:45:39', 'Y'),
(11, 'MAMAN', '', 'bAGUS:-):-(', '2018-01-27', '14:55:32', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `nama_instansi` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `alamat` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `jabatan` varchar(15) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `no_telp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `level` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT 'user',
  `blokir` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `id_session` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`username`, `password`, `nama_instansi`, `alamat`, `jabatan`, `email`, `no_telp`, `level`, `blokir`, `id_session`) VALUES
('admin', '9e9fd118a07ce71377de138407dce91a', 'madiun', 'terminal caruban', 'staff IT', 'dishubkabmadiun@gmail.com', '08562609852', 'admin', 'N', 'ea9g3ghi018rmbvn50bsj78f20'),
('kecamatansukarame', 'c1057a31328172ce50c877059afc73ca', 'Kecamatan Sukarame', 'Jalan Griya Utama No.3 Way Halim Permai', 'viviniz@yahoo.c', 'Staf It', '081978966733', 'user', 'N', 'c1057a31328172ce50c877059afc73ca'),
('kemiling', '545f98aef6fa831cf91a93eb4607cb92', 'kecamatankemiling', 'jl.segitu la', 'staff IT', '565', '085768666668', 'user', 'N', 'hebpb59kodu9pu1bve59nnkf50'),
('tanjungkarangpusat', '21232f297a57a5a743894a0e4a801fc3', 'tanjung karang pusat', 'Jalan Cut Nyak Dien', 'staff IT', '34', '085768666668', 'user', 'N', 'cbrq70mdin0o9ftpoeosg1cnt6'),
('tanjungkarangselatan', '153a5170244de75db154c484f149406c', 'Tanjung Karang Selatan', 'Jalan Cut Nyak Dien', 'staff IT', 'maton.tyasm@gmail.com', '085768666668', 'user', 'N', '153a5170244de75db154c484f149406c'),
('tanjungkarangtimur', '1b288aa8f69d16cf42bdc44892c56588', 'Tanjung Karang Timur', 'Jalan Mayor Jenderal Sutiyoso', 'aanlumut46@yaho', 'staff IT', '085768666668', 'user', 'N', '5it0arp9lfvgsuo7sub649u7c4'),
('maman', '6ffee7d3af984c95d72d813efda2d919', 'PKTJ', 'PKTJ', 'maman@gmail.com', 'taruna', '', 'admin', 'N', 'vh0iaosbpee8222uvghjnp3km6');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
