-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 11, 2017 at 06:46 
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `madiun`
--

-- --------------------------------------------------------

--
-- Table structure for table `hubungi`
--

CREATE TABLE IF NOT EXISTS `hubungi` (
  `id_hubungi` int(5) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `subjek` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `pesan` text COLLATE latin1_general_ci NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id_hubungi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `hubungi`
--

INSERT INTO `hubungi` (`id_hubungi`, `nama`, `email`, `subjek`, `pesan`, `tanggal`) VALUES
(1, 'eko lanang pati', 'eko@gmail.com', 'Mohon Informasi', 'aku gx punya pulsa', '2011-05-10'),
(4, 'dino ariadi', 'dino@yahoo.com', 'Request Code', 'Tolong dunk ..', '2011-05-25'),
(15, 'ETA', 'echa_cici@yahoo.co.id', 'penjelasan', 'Love u', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id_kategori` int(5) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `kategori_seo` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `jenis` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id_kategori`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=48 ;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`, `kategori_seo`, `jenis`, `aktif`) VALUES
(2, 'Cermin Tikungan', 'cermin-tikungan', 'cermin.png', 'Y'),
(19, 'Rambu Petunjuk', 'rambu-petunjuk', 'petunjuk.png', 'Y'),
(21, 'Rambu Perintah', 'rambu-perintah', 'perintah.png', 'Y'),
(22, 'Rambu Peringatan', 'rambu-peringatan', 'peringatan.png', 'Y'),
(23, 'Rambu Larangan', 'rambu-larangan', 'larangan.png', 'Y'),
(36, 'APILL', 'apill', 'apill.png', 'Y'),
(37, 'ATCS', 'atcs', 'atcs.png', 'Y'),
(38, 'Cone', 'cone', 'cone.png', 'Y'),
(39, 'Guardrill', 'guardrill', 'guardrill.png', 'Y'),
(40, 'Kantor', 'kantor', 'kantor.png', 'Y'),
(41, 'Warning Light', 'warning-light', 'warning.png', 'Y'),
(42, 'Zoss', 'zoss', 'zoss.png', 'Y'),
(43, 'DRK', 'drk', 'drk.png', 'Y'),
(44, 'LPJU', 'lpju', 'lpju.png', 'Y'),
(45, 'Terminal', 'terminal', 'terminal.png', 'Y'),
(46, 'Halte', 'halte', 'halte.png', 'Y'),
(47, 'Pelican', 'pelican', 'plc.png', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE IF NOT EXISTS `locations` (
  `id_locations` int(10) NOT NULL AUTO_INCREMENT,
  `id_kategori` int(5) NOT NULL,
  `username` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `judul` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `judul_seo` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci NOT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `address` varchar(145) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `nobangunan` varchar(12) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `telepon` varchar(15) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `kodepos` varchar(15) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `hari` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `gambar` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `gambar2` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `dibaca` int(5) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_locations`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=DYNAMIC AUTO_INCREMENT=862 ;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id_locations`, `id_kategori`, `username`, `judul`, `judul_seo`, `description`, `latitude`, `longitude`, `address`, `nobangunan`, `telepon`, `kodepos`, `hari`, `tanggal`, `jam`, `gambar`, `gambar2`, `dibaca`) VALUES
(861, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', '<table border="0" width="243" style="border-collapse: collapse; width: 182pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="243" height="20" style="width: 182pt; height: 15pt">Perempatan Pucangrejo</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.57898, 111.53385, 'Jalan Sawahan', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '16:55:10', '88IMG_20170418_104410.jpg', '58', 1),
(860, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', '<table border="0" width="243" style="border-collapse: collapse; width: 182pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="243" height="20" style="width: 182pt; height: 15pt">Perempatan Pucangrejo</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.5785, 111.53338, 'Jalan Sawahan', 'Baik', 'Terpasang', 'DAK 2016', 'Kamis', '2017-05-11', '16:54:28', '64IMG_20170418_104224.jpg', '49', 1),
(859, 41, 'admin', 'warningLight', 'warninglight', '<table border="0" width="243" style="border-collapse: collapse; width: 182pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="243" height="20" style="width: 182pt; height: 15pt">Perempatan Pucangrejo</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.57861, 111.53354, 'Jalan Sawahan', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '16:53:47', '41IMG_20170418_104039.jpg', '87', 1),
(858, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', '<table border="0" width="243" style="border-collapse: collapse; width: 182pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="243" height="20" style="width: 182pt; height: 15pt">Perempatan Krokeh</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.57823, 111.53396, 'Jalan Sawahan', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '16:53:05', '98IMG_20170418_103846.jpg', '2', 1),
(857, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', '<table border="0" width="243" style="border-collapse: collapse; width: 182pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="243" height="20" style="width: 182pt; height: 15pt">Pertigaan Buduk</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54474, 111.53546, 'Jalan Kajang', 'Baik', 'Terpasang', '2015', 'Kamis', '2017-05-11', '16:52:20', '15IMG_20170418_095630.jpg', '80', 1),
(856, 41, 'admin', 'warningLight', 'warninglight', '<table border="0" width="243" style="border-collapse: collapse; width: 182pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="243" height="20" style="width: 182pt; height: 15pt">Pertigaan Buduk</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54477, 111.53554, 'Jalan Kajang', 'Baik', 'Terpasang', '2015', 'Kamis', '2017-05-11', '16:51:32', '87IMG_20170418_095604.jpg', '94', 1),
(855, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', '<table border="0" width="243" style="border-collapse: collapse; width: 182pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="243" height="20" style="width: 182pt; height: 15pt">Pertigaan Buduk</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.5449, 111.53613, 'Jalan Kajang', 'Baik', 'Terpasang', '2015', 'Kamis', '2017-05-11', '16:50:42', '63IMG_20170418_095409.jpg', '26', 1),
(854, 41, 'admin', 'warningLight', 'warninglight', '<table border="0" width="243" style="border-collapse: collapse; width: 182pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="243" height="20" style="width: 182pt; height: 15pt">Pertigaan Bagi</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.55412, 111.54439, 'Jalan Candi', 'Baik', 'Terpasang', '2016', 'Kamis', '2017-05-11', '16:49:08', '59IMG_20170418_094556.jpg', '91', 1),
(853, 22, 'admin', 'R.Peringatan', 'rperingatan', '<table border="0" width="243" style="border-collapse: collapse; width: 182pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="243" height="20" style="width: 182pt; height: 15pt">Pertigaan Bagi</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.55437, 111.54503, 'Jalan Candi', 'Baik', 'Terpasang', '2015', 'Kamis', '2017-05-11', '16:48:10', '89IMG_20170418_094348.jpg', '66', 1),
(852, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', '<table border="0" width="243" style="border-collapse: collapse; width: 182pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="243" height="20" style="width: 182pt; height: 15pt">Depan SD Bagi</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.55484, 111.54604, 'Jalan Candi', 'Baik', 'Terpasang', '2011', 'Kamis', '2017-05-11', '16:47:10', '91IMG_20170418_094108.jpg', '11', 1),
(851, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', '<table border="0" width="243" style="border-collapse: collapse; width: 182pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="243" height="20" style="width: 182pt; height: 15pt">Pertigaan Dumpil</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.55681, 111.55077, 'Jalan Candi', 'Baik', 'Terpasang', '2015', 'Kamis', '2017-05-11', '16:46:04', '47IMG_20170418_093815.jpg', '91', 1),
(850, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="250" style="border-collapse: collapse; width: 188pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="250" height="20" style="width: 188pt; height: 15pt">POM Mlilir</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.79657, 111.51404, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:42:15', '13IMG_20170404_104538.jpg', '15', 1),
(849, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="250" style="border-collapse: collapse; width: 188pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="250" height="20" style="width: 188pt; height: 15pt">POM Mlilir</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.79657, 111.51404, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:41:25', '39IMG_20170404_104511.jpg', '43', 1),
(848, 22, 'admin', 'R.Peringatan', 'rperingatan', '<table border="0" width="250" style="border-collapse: collapse; width: 188pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="250" height="20" style="width: 188pt; height: 15pt">POM Mlilir</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.79657, 111.51404, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '2014', 'Kamis', '2017-05-11', '16:40:25', '1IMG_20170404_104447.jpg', '22', 1),
(847, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', '<table border="0" width="250" style="border-collapse: collapse; width: 188pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="250" height="20" style="width: 188pt; height: 15pt">POM Mlilir</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.78961, 111.51813, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:39:12', '19IMG_20170404_104028.jpg', '10', 1),
(846, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="250" style="border-collapse: collapse; width: 188pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="250" height="20" style="width: 188pt; height: 15pt">Pertigaan Umbul</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.78465, 111.52108, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:38:16', '84IMG_20170404_102553.jpg', '97', 1),
(845, 22, 'admin', 'R.Peringatan', 'rperingatan', '<table border="0" width="250" style="border-collapse: collapse; width: 188pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="250" height="20" style="width: 188pt; height: 15pt">Gelonggong</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.77612, 111.52616, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:37:31', '88IMG_20170404_102542.jpg', '34', 1),
(844, 41, 'admin', 'warningLight', 'warninglight', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Gelonggong</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.77612, 111.52616, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:36:34', '41IMG_20170404_102553.jpg', '55', 1),
(843, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Gelonggong</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.77612, 111.52616, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:34:09', '1IMG_20170404_102455.jpg', '6', 1),
(842, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Gelonggong</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.77537, 111.5264, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:32:55', '98IMG_20170404_102010.jpg', '62', 1),
(841, 22, 'admin', 'R.Peringatan', 'rperingatan', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Gelonggong</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.77537, 111.52646, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:31:39', '61IMG_20170404_102058.jpg', '65', 1),
(840, 22, 'admin', 'R.Peringatan', 'rperingatan', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Gelonggong</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.77537, 111.5264, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:30:37', '36IMG_20170404_101950.jpg', '35', 1),
(839, 22, 'admin', 'R.Peringatan', 'rperingatan', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Gelonggong</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.7757, 111.52646, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:29:49', '21IMG_20170404_101933.jpg', '4', 1),
(838, 22, 'admin', 'R.Peringatan', 'rperingatan', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Gelonggong</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.77367, 111.52646, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:28:31', '81IMG_20170404_101717.jpg', '37', 1),
(837, 22, 'admin', 'R.Peringatan', 'rperingatan', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Gelonggong</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.77367, 111.52646, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:27:33', '83IMG_20170404_101546.jpg', '61', 1),
(836, 22, 'admin', 'R.Peringatan', 'rperingatan', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Kantor Desa Gelonggong</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.77284, 111.52656, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '2009', 'Kamis', '2017-05-11', '16:26:22', '12IMG_20170404_100953.jpg', '85', 1),
(835, 22, 'admin', 'R.Peringatan', 'rperingatan', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Kantor Desa Gelonggong</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.77284, 111.52656, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:25:11', '2IMG_20170404_100947.jpg', '29', 1),
(834, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Kantor Desa Gelonggong</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.77253, 111.52655, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:24:24', '56IMG_20170404_100913.jpg', '45', 1),
(833, 41, 'admin', 'warningLight', 'warninglight', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Kantor Desa Gelonggong</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.77253, 111.52655, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', 'APBD 2016', 'Kamis', '2017-05-11', '16:23:38', '79IMG_20170404_100901.jpg', '46', 1),
(832, 22, 'admin', 'R.Peringatan', 'rperingatan', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Gelonggong</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.77151, 111.52663, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '2009', 'Kamis', '2017-05-11', '16:22:09', '93IMG_20170404_100653.jpg', '31', 1),
(831, 22, 'admin', 'R.Peringatan', 'rperingatan', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Pasar Hewan Dolopo</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.76632, 111.52683, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:21:04', '69IMG_20170404_100445.jpg', '6', 1),
(830, 22, 'admin', 'R.Peringatan', 'rperingatan', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Pasar Hewan Dolopo</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.76578, 111.52694, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:20:14', '50IMG_20170404_100116.jpg', '11', 1),
(829, 41, 'admin', 'warningLight', 'warninglight', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Pasar Hewan Dolopo</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.76578, 111.52694, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', 'APBD 2016', 'Kamis', '2017-05-11', '16:19:28', '74IMG_20170404_100038.jpg', '47', 1),
(828, 22, 'admin', 'R.Peringatan', 'rperingatan', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Depan PLN Dolopo</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.76387, 111.52687, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:18:30', '5IMG_20170404_095728.jpg', '98', 1),
(827, 36, 'admin', 'APILL', 'apill', '<table border="0" width="228" style="border-collapse: collapse; width: 171pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="228" height="20" style="width: 171pt; height: 15pt">Depan PLN Dolopo</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.6224, 111.527, 'Jalan Raya Ponorogo - Madiun', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:17:40', '49IMG_20170404_094810.jpg', '60', 1),
(826, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="219" style="border-collapse: collapse; width: 164pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="219" height="20" style="width: 164pt; height: 15pt">Depan Toko Banjir Rejeki</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54356, 111.65833, 'Jl.Ahmad Yani 116 Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:14:06', '86IMG_20170330_113453.jpg', '61', 1),
(825, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Pertigaan Kayo</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.5401, 111.65838, 'Jl.Ahmad Yani 116 Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:13:03', '94IMG_20170330_114205.jpg', '87', 1),
(824, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Pertigaan Kayo</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.5401, 111.65838, 'Jl.Ahmad Yani 116 Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:11:51', '72IMG_20170330_114122.jpg', '13', 1),
(823, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Depan Toko Sepeda</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54766, 111.65708, 'Jl.Ahmad Yani 14 Krajan Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:10:53', '65IMG_20170330_112607.jpg', '18', 1),
(822, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Toko Shara</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54654, 111.65726, 'Jl.Ahmad Yani 116 Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:10:04', '90IMG_20170330_112835.jpg', '20', 1),
(821, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Toko Gemilang</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54532, 111.65771, 'Jl.Ahmad Yani 116 Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:09:07', '63IMG_20170330_113034.jpg', '92', 1),
(820, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Polsek Mejayan</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54465, 111.65784, 'Jl.Ahmad Yani 116 Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:08:15', '20IMG_20170330_113203.jpg', '97', 1),
(819, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Perempatan Gang 9 Krajan</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54356, 111.65833, 'Jl.Ahmad Yani 116 Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:07:26', '43IMG_20170330_113417.jpg', '3', 1),
(818, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Pertigaan Diponegoro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54245, 111.65836, 'Jl.Ahmad Yani 116 Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:06:11', '38IMG_20170330_113728.jpg', '72', 1),
(817, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">RM.Embun Pagi</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.5419, 111.65835, 'Jl.Ahmad Yani 116 Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:04:19', '87IMG_20170330_113911.jpg', '12', 1),
(816, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Pertigaan Kayo</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.5401, 111.65838, 'Jl.Ahmad Yani 116 Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:03:35', '7IMG_20170330_114205.jpg', '87', 1),
(815, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Barat Pertigaan Kayo</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.53987, 111.65806, 'Jl.Ahmad Yani 116 Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:02:46', '73IMG_20170330_114357.jpg', '78', 1),
(814, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Depan Pom Bensin Bangunsari</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.53905, 111.65664, 'Jl.Ahmad Yani 116 Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:01:42', '8IMG_20170330_114535.jpg', '39', 1),
(813, 44, 'admin', 'LPJU', 'lpju', '<font size="3">Depan RS.Panti Waluyo</font>\r\n<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n	</tbody>\r\n</table>\r\n', -7.53871, 111.65594, 'Jl.Ahmad Yani 116 Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '16:00:41', '4IMG_20170330_114702.jpg', '62', 1),
(812, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Jalan Diponegoro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.53251, 111.6589, 'Jl.Diponegoro Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:59:23', '49IMG_20170330_115234.jpg', '97', 1),
(811, 46, 'admin', 'Halte', 'halte', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Jalan Diponegoro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54251, 111.6589, 'Jl.Diponegoro Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:58:00', '56IMG_20170330_115249.jpg', '79', 1),
(810, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Jalan Diponegoro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54216, 111.65945, 'Jl.Diponegoro Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:56:47', '84IMG_20170330_115440.jpg', '53', 1),
(809, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Jalan Diponegoro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54225, 111.66066, 'Jl.Diponegoro Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:56:03', '61IMG_20170330_115610.jpg', '96', 1),
(808, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="232" style="border-collapse: collapse; width: 174pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="232" height="20" style="width: 174pt; height: 15pt">Jalan Diponegoro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54208, 111.66145, 'Jl.Diponegoro Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:55:07', '16IMG_20170330_115744.jpg', '47', 1),
(807, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Jalan Diponegoro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54244, 111.66269, 'Jl.Diponegoro Bangunsari', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:52:45', '95IMG_20170330_115929.jpg', '28', 1),
(806, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Pertigaan Jalan Dr.Sutomo</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54316, 111.66474, 'Jl.Singoludro 16 Bajulan Saradan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:50:43', '97IMG_20170330_120138.jpg', '70', 1),
(805, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Jalan Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54244, 111.66692, 'Jl.Singoludro 16 Bajulan Saradan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:49:51', '87IMG_20170330_120334.jpg', '39', 1),
(804, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Jalan Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54286, 111.66856, 'Jl.Singoludro - Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:49:03', '32IMG_20170330_120528.jpg', '62', 1),
(803, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Jalan Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54424, 111.6728, 'Jl.Singoludro - Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:48:18', '16IMG_20170330_120800.jpg', '47', 1),
(802, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Jalan Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54433, 111.67335, 'Jl.Singoludro - Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:47:17', '72IMG_20170330_120938.jpg', '14', 1),
(801, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Jalan Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54477, 111.67321, 'Jl.Singoludro - Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:46:35', '7IMG_20170330_121116.jpg', '16', 1),
(800, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Jalan Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54498, 111.67333, 'Jl.Singoludro - Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:45:37', '22IMG_20170330_121248.jpg', '66', 1),
(799, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Jalan Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.5455, 111.67334, 'Jl.Singoludro - Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:44:20', '40IMG_20170330_121414.jpg', '62', 1),
(798, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Jalan Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54573, 111.67321, 'Jl.Singoludro - Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:43:17', '34IMG_20170330_121530.jpg', '10', 1),
(797, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Jalan Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54661, 111.67321, 'Jl.Singoludro - Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:41:59', '44IMG_20170330_121647.jpg', '51', 1),
(796, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Jalan Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54661, 111.67321, 'Jl.Singoludro - Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:40:51', '11IMG_20170330_121812.jpg', '85', 1),
(795, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Jalan Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54681, 111.67308, 'Jl.Singoludro - Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:39:52', '95IMG_20170330_121923.jpg', '98', 1),
(794, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Jalan Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54724, 111.67309, 'Jl.Singoludro - Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:28:54', '7IMG_20170330_122051.jpg', '83', 1),
(793, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Depan Homestay Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54757, 111.67309, 'Jl.Singoludro - Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:27:48', '24IMG_20170330_122209.jpg', '69', 1),
(792, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Depan Homestay Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54809, 111.67301, 'Jl.Singoludro - Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:26:23', '25IMG_20170330_122335.jpg', '45', 1),
(791, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">SMAN 1 Mejayan</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54819, 111.6525, 'Jl.Panglima Sudirman 65 Krajan Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:23:28', '7IMG_20170330_111513.jpg', '80', 1),
(790, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="227" style="border-collapse: collapse; width: 170pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="227" height="20" style="width: 170pt; height: 15pt">Depan Toko Besi Rajawali</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54821, 111.65403, 'Jl.Panglima Sudirman 52 Krajan Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:22:30', '17IMG_20170330_111052.jpg', '59', 1),
(789, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="288" style="border-collapse: collapse; width: 216pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="288" height="20" style="width: 216pt; height: 15pt">Depan Taman Kota Mejayan</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54821, 111.65539, 'Jl. Panglima Sudirman 25 Krajan Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:13:21', '72IMG_20170330_110524.jpg', '96', 1),
(788, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="288" style="border-collapse: collapse; width: 216pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="288" height="20" style="width: 216pt; height: 15pt">Pertigaan POS 903</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54808, 111.657, 'Jl. Raya Surabaya - Madiun 164 Krajan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:12:28', '87IMG_20170330_105959.jpg', '68', 1),
(787, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="288" style="border-collapse: collapse; width: 216pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="288" height="20" style="width: 216pt; height: 15pt">Depan BRI Mejayan</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54826, 111.65908, 'Jl. Panglima Sudirman 159 Krajan Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:11:31', '98IMG_20170330_105315.jpg', '34', 1),
(786, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="288" style="border-collapse: collapse; width: 216pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="288" height="20" style="width: 216pt; height: 15pt">Perempatan Masjid Al-Arifiyah Caruban</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54843, 111.66069, 'Jl. Panglima Sudirman 117 Pandean', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:10:33', '88IMG_20170330_104923.jpg', '62', 1),
(785, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="288" style="border-collapse: collapse; width: 216pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="288" height="20" style="width: 216pt; height: 15pt">Pertigaan Jalan Dr.Sutomo</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54875, 111.66309, 'Jl. Dr. Sutomo - Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:09:27', '13IMG_20170330_104211.jpg', '58', 1),
(784, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="288" style="border-collapse: collapse; width: 216pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="288" height="20" style="width: 216pt; height: 15pt">Pasar Burung Mejayan</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54931, 111.66479, 'Jl. Panglima Sudirman 69 Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:08:36', '24IMG_20170330_103854.jpg', '82', 1),
(783, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="288" style="border-collapse: collapse; width: 216pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="288" height="20" style="width: 216pt; height: 15pt">Pom Bensin Mejayan</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54911, 111.66656, 'Jl. Panglima Sudirman 69 Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:07:20', '95IMG_20170330_103426.jpg', '83', 1),
(782, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="288" style="border-collapse: collapse; width: 216pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="288" height="20" style="width: 216pt; height: 15pt">SMPN 1 Mejayan</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54896, 111.66809, 'Jl. Panglima Sudirman 69 Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:06:06', '47IMG_20170330_103107.jpg', '18', 1),
(781, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="288" style="border-collapse: collapse; width: 216pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="288" height="20" style="width: 216pt; height: 15pt">Puskesmas Mejayan</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54882, 111.6697, 'Jl. Panglima Sudirman 69 Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:05:09', '72IMG_20170330_102652.jpg', '77', 1),
(780, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="288" style="border-collapse: collapse; width: 216pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="288" height="20" style="width: 216pt; height: 15pt">Terminal Caruban</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54893, 111.67111, 'Jl. Panglima Sudirman 69 Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:03:28', '60IMG_20170330_102251.jpg', '11', 1),
(779, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="288" style="border-collapse: collapse; width: 216pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="288" height="20" style="width: 216pt; height: 15pt">Pertigaan PDAM Singoludro</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54891, 111.6729, 'Jl. Panglima Sudirman 12 Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:02:30', '23IMG_20170330_101818.jpg', '54', 1),
(778, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="288" style="border-collapse: collapse; width: 216pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="288" height="20" style="width: 216pt; height: 15pt">Kantor KEMENAG</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.5489, 111.67429, 'Jl. Panglima Sudirman 12 Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:01:22', '17IMG_20170330_101302.jpg', '51', 1),
(777, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="288" style="border-collapse: collapse; width: 216pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="288" height="20" style="width: 216pt; height: 15pt">Pertigaan Bungkus</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54891, 111.67553, 'Jl. Panglima Sudirman 12 Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '15:00:28', '74IMG_20170330_101302.jpg', '80', 1),
(776, 44, 'admin', 'LPJU', 'lpju', '<table border="0" width="288" style="border-collapse: collapse; width: 216pt">\r\n	<tbody>\r\n		<tr height="20" style="height: 15pt">\r\n			<td class="xl29" width="288" height="20" style="width: 216pt; height: 15pt">Kantor Imigrasi</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', -7.54885, 111.67789, 'Jl. Panglima Sudirman 12 Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:59:27', '21IMG_20170330_100305.jpg', '79', 1),
(775, 44, 'admin', 'LPJU', 'lpju', 'Pertigaan Ngepeh\r\n', -7.54899, 111.67966, 'Jl. Panglima Sudirman 12 Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:58:30', '6IMG_20170330_095905.jpg', '71', 1),
(773, 44, 'admin', 'LPJU', 'lpju', 'Batas Ngepeh - Mejayan\r\n', -7.54941, 111.68201, 'Jl. Panglima Sudirman 12 Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:55:56', '44IMG_20170330_094209.jpg', '91', 1),
(774, 44, 'admin', 'LPJU', 'lpju', 'Kantor Pemasaran Perumnas Ngepeh\r\n', -7.54908, 111.68094, 'Jl. Panglima Sudirman 12 Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:57:23', '24IMG_20170330_095332.jpg', '86', 1),
(772, 44, 'admin', 'LPJU', 'lpju', 'Batas Ngepeh - Mejayan\r\n', -7.54945, 111.68202, 'Jl. Panglima Sudirman 12 Mejayan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:54:45', '30IMG_20170330_094126.jpg', '13', 1),
(770, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Depan kantor Desa Tiron\r\n', -7.58344, 111.543147, 'Jl.Raya Surabaya-Madiun Nglames', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:46:43', '92IMG_20170322_120602.jpg', '49', 1),
(771, 41, 'admin', 'warningLight', 'warninglight', 'Depan pabrik sampoerna\r\n', -7.58497, 111.54081, 'Jl.Raya Surabaya-Madiun Nglames', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:49:32', '', '', 1),
(769, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Kecamatan dagangan\r\n', -7.70813, 111.55349, 'Perempatan Pintu', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '14:42:26', '7IMG_20170403_121850.jpg', '37', 1),
(767, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Kecamatan Dagangan\r\n', -7.7082, 111.55298, 'Perempatan Pintu', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '14:41:00', '37IMG_20170403_121650.jpg', '43', 1),
(768, 44, 'admin', 'LPJU', 'lpju', 'Kecamatan Dagangan\r\n', -7.708, 111.55303, 'Perempatan Pintu', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '14:41:44', '14IMG_20170403_121754.jpg', '36', 1),
(766, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Kecamatan Dagangan\r\n', -7.70793, 111.55248, 'Perempatan Pintu', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '14:40:17', '48IMG_20170403_120907.jpg', '64', 1),
(765, 41, 'admin', 'warningLight', 'warninglight', 'Kecamatan dagangan\r\n', -7.70795, 111.55293, 'Perempatan Pintu', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '14:39:18', '87IMG_20170403_120705.jpg', '41', 1),
(764, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Kecamatan Dagangan\r\n', -7.70769, 111.55306, 'Perempatan Pintu', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '14:38:31', '96IMG_20170403_120517.jpg', '74', 1),
(763, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Kecamatan Dagangan\r\n', -7.70191, 111.55591, 'Perempatan Pintu', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '14:37:23', '37IMG_20170403_120239.jpg', '48', 1),
(761, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Kecamatan dagangan\r\n', -7.68349, 111.55049, 'Pertigaan Dagangan', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '14:34:53', '12IMG_20170403_115349.jpg', '29', 1),
(762, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Kecamatan Dagangan\r\n', -7.68407, 111.55051, 'Pertigaan Dagangan', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '14:36:18', '', '', 1),
(760, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Kecamatan Dagangan\r\n', -7.68535, 111.55107, 'Pertigaan Dagangan', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '14:33:59', '5IMG_20170403_114917.jpg', '52', 1),
(759, 21, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Dagagan\r\n', -7.68554, 111.60616, 'Madiun - Dungus', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:30:12', '91IMG_20170403_114033.jpg', '98', 1),
(758, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Pertigaan Ngebrak\r\n', -7.68739, 111.6136, 'Madiun - Dungus', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:29:18', '19IMG_20170403_095356.jpg', '51', 1),
(756, 41, 'admin', 'warningLight', 'warninglight', 'Pertigaan Ngbrak\r\n', -7.68669, 111.61308, 'Madiun - Dungus', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:27:52', '61IMG_20170403_094853.jpg', '94', 1),
(757, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Pertigaan Ngbrak\r\n', -7.686653, 111.61394, 'Madiun - Dungus', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:28:37', '4IMG_20170403_095109.jpg', '25', 1),
(755, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Pertigaan Ngeblak\r\n', -7.68675, 111.61275, 'Madiun - Dungus', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:26:58', '27IMG_20170403_094547.jpg', '21', 1),
(754, 44, 'admin', 'LPJU', 'lpju', 'Pasar Wungu\r\n', -7.6824, 111.60733, 'Madiun - Dungus', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:25:38', '84IMG_20170403_094205.jpg', '73', 1),
(753, 41, 'admin', 'warningLight', 'warninglight', 'Pasar wunghu\r\n', -7.68508, 111.60695, 'Madiun - Dungus', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:24:54', '88IMG_20170403_093911.jpg', '54', 1),
(752, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Pasar wungu\r\n', -7.68426, 111.60623, 'Madiun - Dungus', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:24:04', '91IMG_20170403_093553.jpg', '27', 1),
(751, 41, 'admin', 'warningLight', 'warninglight', 'Perum Mojo purno\r\n', -7.65564, 111.55543, 'Madiun - Dungus', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:23:28', '67IMG_20170403_092321.jpg', '39', 1),
(750, 41, 'admin', 'warningLight', 'warninglight', 'Kecamatan Wungu\r\n', -7.6493, 111.55162, 'Madiun - Dungus', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:22:31', '36IMG_20170403_091916.jpg', '47', 1),
(749, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Kecamatan wungu\r\n', -7.64683, 111.55154, 'Kecamatan Wungu', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '14:21:37', '91IMG_20170403_091834.jpg', '42', 1),
(748, 44, 'admin', 'LPJU', 'lpju', 'Pertigaan Mundu\r\n', -7.64875, 111.7329, 'Saradan - Gemarang', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:18:05', '22IMG_20170330_104745.jpg', '74', 1),
(746, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Peetigaan Mundu\r\n', -7.64915, 111.73297, 'Gemarang - Kare', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '14:16:22', '1IMG_20170330_104144.jpg', '98', 1),
(747, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Pertigaan Mundu\r\n', -7.55544, 111.75614, 'Gemarang - Gososng', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '14:17:15', '38IMG_20170330_104618.jpg', '78', 1),
(745, 41, 'admin', 'warningLight', 'warninglight', 'Pertigaan MUndu\r\n', -7.64867, 111.73278, 'Saradan - Gemarang', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:15:32', '37IMG_20170330_104030.jpg', '14', 1),
(744, 46, 'admin', 'Halte', 'halte', 'Pasar Mundu\r\n', -7.64949, 111.73254, 'Saradan - Gemarang', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '14:14:38', '75IMG_20170330_104046.jpg', '61', 1),
(743, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Pasar Mundu\r\n', -7.64811, 111.73288, 'Saradan - Gemarang', 'Baik', 'Terpasang', 'DAK 2013', 'Kamis', '2017-05-11', '14:13:43', '65IMG_20170330_103715.jpg', '64', 1),
(741, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Utara Perempatan Muneng\r\n', -7.48819, 111.60442, 'Jl.Protokol Muneng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:50:57', '50IMG_20170321_122514.jpg', '94', 1),
(742, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Utara Perempatan Muneng\r\n', -7.48921, 111.60333, 'Jl.Protokol Muneng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:51:52', '1IMG_20170322_095917.jpg', '53', 1),
(740, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Utara Perempatan Muneng\r\n', -7.48819, 111.60442, 'Jl.Protokol Muneng', 'sedang', 'Terpasang', '', 'Kamis', '2017-05-11', '13:49:58', '78IMG_20170321_122251.jpg', '14', 1),
(739, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Depan Sd Ngale\r\n', -7.47799, 111.62039, 'Jl.Ngale', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:48:52', '72IMG_20170321_120825.jpg', '21', 1),
(738, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Depan Kantor Desa Ngale\r\n', -7.47799, 111.62039, 'Jl.Ngale', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:47:58', '63IMG_20170321_112756.jpg', '35', 1),
(737, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'SMP 01 Pilakeenceng\r\n', -7.47921, 111.64473, 'Jl.Kenongrejo - pilakanceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:46:56', '57IMG_20170321_115515.jpg', '9', 1),
(736, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'SMP 1 Pilakenceng\r\n', -7.47921, 111.64473, 'Jl.Kenongorejo - Pilangkenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:45:44', '56IMG_20170321_115427.jpg', '56', 1),
(735, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Ngengor\r\n', -7.47984, 111.64866, 'Jl.Raya Ngengor - Pilakenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:44:15', '84IMG_20170321_115215.jpg', '73', 1),
(734, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Ngengor\r\n', -7.47984, 111.64866, 'Jl.Raya Ngengor - Pilakenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:43:29', '12IMG_20170321_115126.jpg', '68', 1),
(732, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Ngengor\r\n', -7.4818, 111.65371, 'Jl.Raya Ngengor - Pilakenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:40:14', '33IMG_20170321_114439.jpg', '13', 1),
(733, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Ngengor\r\n', -7.4818, 111.65371, 'Jl.Raya Ngengor - Pilakenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:42:34', '81IMG_20170321_114530.jpg', '81', 1);
INSERT INTO `locations` (`id_locations`, `id_kategori`, `username`, `judul`, `judul_seo`, `description`, `latitude`, `longitude`, `address`, `nobangunan`, `telepon`, `kodepos`, `hari`, `tanggal`, `jam`, `gambar`, `gambar2`, `dibaca`) VALUES
(731, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Barat Pasar Tlagan\r\n', -7.48451, 111.66086, 'Jl.Kenongorejo - Pilangkenceng', 'Baik', 'Terpasang', '2013', 'Kamis', '2017-05-11', '13:38:51', '28IMG_20170321_112909.jpg', '47', 1),
(730, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Timur Pasar Tlagan\r\n', -7.48451, 111.66086, 'Jl.Kenongorejo - Pilangkenceng', 'Baik', 'Terpasang', '2013', 'Kamis', '2017-05-11', '13:36:55', '73IMG_20170321_112756.jpg', '79', 1),
(729, 41, 'admin', 'warningLight', 'warninglight', 'Pasar Telagan\r\n', -7.48451, 111.66086, 'Jl.Kenongrejo - pilakanceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:35:47', '49IMG_20170321_112711.jpg', '37', 1),
(728, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Pasar Telagan\r\n', -7.48451, 111.66086, 'Jl.Kenongrejo - pilakanceng', 'Baik', 'Terpasang', '2013', 'Kamis', '2017-05-11', '13:34:36', '34IMG_20170321_112550.jpg', '9', 1),
(727, 44, 'admin', 'LPJU', 'lpju', 'Pasar Telagan\r\n', -7.48451, 111.66086, 'Jl.Kenongrejo - pilakanceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:33:28', '26IMG_20170321_112653.jpg', '67', 1),
(725, 44, 'admin', 'LPJU', 'lpju', 'Depan Kantor Desa Kenongrejo\r\n', -7.48958, 111.66263, 'Jl.Kenongrejo - pilakanceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:30:52', '85IMG_20170321_112506.jpg', '2', 1),
(726, 44, 'admin', 'LPJU', 'lpju', 'Pasar Telagan\r\n', -7.48451, 111.66086, 'Jl.Kenongrejo - pilakanceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:32:15', '70IMG_20170321_112506.jpg', '92', 1),
(724, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'SDN 02 Kenongrejp\r\n', -7.48958, 111.66263, 'Jl.Kenongrejo - pilakanceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:29:47', '84IMG_20170321_111935.jpg', '70', 1),
(723, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'SDN 02 Kenongrejo\r\n', -7.48958, 111.66263, 'Jl.Kenongrejo - pilakanceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:28:46', '5IMG_20170321_111851.jpg', '58', 1),
(722, 44, 'admin', 'LPJU', 'lpju', 'Pertigaan Pondok Kenongrejo\r\n', -7.48958, 111.66263, 'Jl.Kenongrejo - pilakanceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:27:45', '30IMG_20170321_111521.jpg', '33', 1),
(721, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'SMA N 01 Pilakenceng\r\n', -7.49058, 111.66325, 'Jl.Kenongrejo - pilakanceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:26:43', '14IMG_20170321_110607.jpg', '1', 1),
(720, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'SMAN 1 Pilakenceng\r\n', -7.49058, 111.66325, 'Jl.Kenongrejo - pilakanceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:24:42', '9IMG_20170321_110525.jpg', '22', 1),
(718, 44, 'admin', 'LPJU', 'lpju', 'Depan Kecamatan Pilakenceng\r\n', -7.49058, 111.66325, 'jl. Kenongrejo - Pilakenceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:22:21', '19IMG_20170321_110640.jpg', '8', 1),
(719, 44, 'admin', 'LPJU', 'lpju', 'Depan Kec. Pilakenceng\r\n', -7.49058, 111.66325, 'jl. Kenongrejo - Pilakenceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:23:35', '59IMG_20170321_110710.jpg', '4', 1),
(717, 44, 'admin', 'LPJU', 'lpju', 'Depan Kec.Pilakanceng\r\n', -7.49058, 111.66325, 'Jl.Kenongrejo - pilakanceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:20:47', '1IMG_20170321_110507.jpg', '1', 1),
(716, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Pertigaan Sumbergandu\r\n', -7.5011, 111.66498, 'SumberGandu - Pilakenceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:19:05', '26IMG_20170321_103348.jpg', '40', 1),
(714, 44, 'admin', 'LPJU', 'lpju', 'Pertigaan Sumbergandu\r\n', -7.5011, 111.66498, 'SumberGandu - Pilakenceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:17:01', '73IMG_20170321_103103.jpg', '80', 1),
(715, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Pertigaan Sumbergandu\r\n', -7.5011, 111.66498, 'SumberGandu - Pilakenceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:17:56', '87IMG_20170321_103103.jpg', '17', 1),
(713, 41, 'admin', 'warningLight', 'warninglight', 'Pertigaan Sumbergandu\r\n', -7.5011, 111.66498, 'SumberGandu - Pilakenceng', 'Mati', 'Terpasang', '', 'Kamis', '2017-05-11', '13:16:15', '96IMG_20170321_103050.jpg', '65', 1),
(712, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Pertigaan Sumbergandu\r\n', -7.5011, 111.66498, 'SumberGandu - Pilakenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:15:25', '15IMG_20170321_103020.jpg', '17', 1),
(711, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Pertigaan SumberGandu\r\n', -7.5011, 111.66498, 'SumberGandu - Pilakenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:14:32', '58IMG_20170321_102954.jpg', '14', 1),
(710, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Pertigaan Sumbergandu\r\n', -7.5011, 111.66498, 'SumberGandu - Pilakenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:13:05', '53IMG_20170321_102902.jpg', '92', 1),
(709, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'SDN 02 SumberGandu\r\n', -7.50345, 111.66427, 'SumberGandu - Pilakenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:12:11', '48IMG_20170321_102409.jpg', '76', 1),
(708, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'SDN 2 Sumbergandu\r\n', -7.50345, 111.66427, 'SumberGandu - Pilakenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:10:54', '41IMG_20170321_102323.jpg', '95', 1),
(706, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'MTsN Pilakenceng\r\n', -7.50532, 111.66437, 'SumberGandu - Pilakenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:08:32', '81IMG_20170321_101722.jpg', '69', 1),
(707, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'MTsN Pilakenceng\r\n', -7.50532, 111.66437, 'SumberGandu - Pilakenceng', 'Baik', 'Terpasang', '2016', 'Kamis', '2017-05-11', '13:09:43', '96IMG_20170321_101750.jpg', '19', 1),
(705, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'SMP N 2 Pilakenceng\r\n', -7.50909, 111.66426, 'Jl. Raya Puilakenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:07:14', '80IMG_20170321_101242.jpg', '57', 1),
(703, 39, 'admin', 'Guardrill', 'guardrill', 'Letter S Kedungmaron\r\n', -7.51445, 111.66463, 'Kedungmoron - Pilakenceng', 'Baik', 'Kebutuhan', '', 'Kamis', '2017-05-11', '13:04:12', '28IMG_20170321_095934.jpg', '58', 1),
(704, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'SMP N 2 Pilakenceng\r\n', -7.50909, 111.66426, 'Jl.Raya Pilakenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '13:05:32', '28IMG_20170321_101037.jpg', '3', 1),
(702, 39, 'admin', 'Guardrill', 'guardrill', 'Letter S kedungmaron\r\n', -7.51445, 111.66463, 'Kedungmoron - Pilakenceng', 'Baik', 'Kebutuhan', '', 'Kamis', '2017-05-11', '13:03:13', '83IMG_20170321_095900.jpg', '36', 1),
(700, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Letter S Kedungmaron\r\n', -7.51445, 111.66463, 'Kedungmoron - Pilakenceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:56:09', '2IMG_20170321_095809.jpg', '61', 1),
(701, 44, 'admin', 'LPJU', 'lpju', 'Letter S KedungMaron\r\n', -7.51445, 111.66463, 'Kedungmoron - Pilakenceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '13:02:06', '18IMG_20170321_095844.jpg', '35', 1),
(699, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Letter S Kedungmaron\r\n', -7.51445, 111.66463, 'Kedungmoron - Pilakenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '12:54:51', '78IMG_20170321_095738.jpg', '55', 1),
(698, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Letter S Kedungmaron\r\n', -7.51445, 111.66463, 'Kedungmoron - Pilakenceng', 'Baik', 'Terpasang', '2012', 'Kamis', '2017-05-11', '12:53:38', '85IMG_20170321_095653.jpg', '18', 1),
(697, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Letter S Kedungmaron\r\n', -7.51445, 111.66463, 'Kedungmoron - Pilakenceng', 'Baik', 'Terpasang', 'APBD 2012', 'Kamis', '2017-05-11', '12:52:44', '86IMG_20170321_095556.jpg', '34', 1),
(695, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Pertigaan Kedungrejo\r\n', -7.52176, 111.66213, 'Kedungrejo', '', 'Kebutuhan', '', 'Kamis', '2017-05-11', '12:46:16', '70IMG_20170321_094323.jpg', '36', 1),
(696, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Depan SD Kedungrejo\r\n', -7.51849, 111.66298, 'Kedungrejo', 'Baik', 'Terpasang', 'APBD 2012', 'Kamis', '2017-05-11', '12:51:19', '87IMG_20170321_094946.jpg', '97', 1),
(694, 44, 'admin', 'LPJU', 'lpju', 'Pertigaaan Kedungrejo\r\n', -7.52176, 111.66213, 'Kedungrejo', '', 'Kebutuhan', '', 'Kamis', '2017-05-11', '12:43:18', '67IMG_20170321_094323.jpg', '73', 1),
(692, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Utara Pertigaan Bajulan\r\n', -7.5304, 111.66007, 'Jl. Bajulan PuilangKenceng', 'Baik', 'Terpasang', 'DAK 2016', 'Kamis', '2017-05-11', '12:33:02', '38IMG_20170321_093436.jpg', '7', 1),
(693, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Pertigaan Kedungrejo\r\n', -7.52176, 111.66213, 'Kedungrejo', '', 'Kebutuhan', '', 'Kamis', '2017-05-11', '12:42:32', '75IMG_20170321_094323.jpg', '42', 1),
(691, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Utara Pertigaan Bajulan\r\n', -7.5304, 111.66007, 'Jl.Bajulan - PilangKenceng', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:30:15', '58IMG_20170320_120908.jpg', '85', 1),
(690, 23, 'admin', 'R. Larangan', 'r-larangan', 'Depan Perguruan Sukorejo\r\n', -7.53814, 111.68384, 'Jl.Perguruan Sukorejo', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:29:14', '5IMG_20170320_120433.jpg', '4', 1),
(689, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Depan Perguruan Sukorejo\r\n', -7.53814, 111.68384, 'Jl.Perguruan Sukorejo', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:28:05', '16IMG_20170320_120355.jpg', '53', 1),
(688, 39, 'admin', 'Guardrill', 'guardrill', 'Selatan Perguruan Sukorejo\r\n', -7.53814, 111.68384, 'Jl.Perguruan Sukorejo', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:26:38', '11IMG_20170320_115447.jpg', '48', 1),
(686, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Pasar Sukorejo\r\n', -7.54022, 111.68064, 'Jl. Gajah Mada - Ngepeh', '', 'Kebutuhan', '', 'Kamis', '2017-05-11', '12:24:15', '27IMG_20170320_115220.jpg', '63', 1),
(687, 47, 'admin', 'LPJU', 'lpju', 'Selatan Perguruan Sukorejo\r\n', -7.53814, 111.68384, 'Jl.Perguruan Sukorejo', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:25:41', '2IMG_20170320_115422.jpg', '65', 1),
(685, 44, 'admin', 'LPJU', 'lpju', 'Pasar Sukorejo\r\n', -7.54022, 111.68064, 'Jl. Gajah Mada - Ngepeh', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:23:21', '69IMG_20170320_115103.jpg', '13', 1),
(683, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Utara Pertigaan Ngepeh\r\n', -7.54821, 111.68006, 'Jl. Gajah Mada - Ngepeh', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:20:46', '20IMG_20170320_114608.jpg', '35', 1),
(684, 44, 'admin', 'LPJU', 'lpju', 'Pasar Sukorejo\r\n', -7.54022, 111.68064, 'Jl. Gajah Mada - Ngepeh', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:22:28', '82IMG_20170320_115046.jpg', '16', 1),
(682, 36, 'admin', 'APILL', 'apill', 'Pertigaan Rel Kaligunting\r\n', -7.54987, 111.69026, 'Jl.Supriyadi - Bongsopotro', 'Mati', 'Terpasang', '', 'Kamis', '2017-05-11', '12:19:29', '55IMG_20170320_114200.jpg', '20', 1),
(681, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Utara Kantor Desa Bogospotro\r\n', -7.54987, 111.69026, 'Jl.Supriyadi - Bongsopotro', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:18:11', '9IMG_20170320_114002.jpg', '24', 1),
(680, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Tikungan Bogospotro\r\n', -7.5391, 111.69233, 'Jl.Supriyadi - Bongsopotro', 'Rusak', 'Terpasang', '', 'Kamis', '2017-05-11', '12:16:59', '72IMG_20170320_113714.jpg', '41', 1),
(678, 44, 'admin', 'LPJU', 'lpju', 'Tikungan Bogospotro\r\n', -7.5391, 111.69233, 'Jl.Supriyadi - Bongsopotro', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:14:30', '14IMG_20170320_113323.jpg', '96', 1),
(679, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Tikungan Bogospotro\r\n', -7.5391, 111.69233, 'Jl.Supriyadi - Bongsopotro', 'sedang', 'Terpasang', '', 'Kamis', '2017-05-11', '12:15:58', '37IMG_20170320_113339.jpg', '20', 1),
(677, 41, 'admin', 'warningLight', 'warninglight', 'Tikungan Bogospotro\r\n', -7.5391, 111.69233, 'Jl.Bener - Duren', 'Mati', 'Terpasang', '', 'Kamis', '2017-05-11', '12:13:11', '60IMG_20170320_113206.jpg', '14', 1),
(676, 41, 'admin', 'warningLight', 'warninglight', 'Tikungan Bogospotro\r\n', -7.5391, 111.69233, 'Jl.Bener - Duren', 'Mati', 'Terpasang', '', 'Kamis', '2017-05-11', '12:13:09', '79IMG_20170320_113206.jpg', '83', 1),
(675, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Tikungan Bogospotro\r\n', -7.5391, 111.69233, 'Jl.Supriyadi - Bongsopotro', 'sedang', 'Terpasang', '', 'Kamis', '2017-05-11', '12:11:43', '40IMG_20170320_112025.jpg', '36', 1),
(673, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Timur Sukorejo\r\n', -7.53818, 111.68765, 'Jl. Supriyadi - Sukorejo', 'sedang', 'Terpasang', '', 'Kamis', '2017-05-11', '12:09:22', '73IMG_20170320_112025.jpg', '22', 1),
(674, 39, 'admin', 'Guardrill', 'guardrill', 'Tikungan Bogospotro\r\n', -7.5379, 111.68774, 'Jl.Supriyadi - Bongsopotro', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:10:39', '68IMG_20170320_112215.jpg', '18', 1),
(672, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Timur Sukorejo\r\n', -7.53137, 111.68439, 'Jl. Supriyadi - Sukorejo', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:07:09', '34IMG_20170320_111825.jpg', '76', 1),
(671, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Timur Sukorejo\r\n', -7.53137, 111.68439, 'Jl. Supriyadi - Sukorejo', 'sedang', 'Terpasang', '', 'Kamis', '2017-05-11', '12:06:22', '28IMG_20170320_111712.jpg', '70', 1),
(670, 36, 'admin', 'APILL', 'apill', 'Perempatan Sukorejo\r\n', -7.53713, 111.68439, 'Jl. Supriyadi - Sukorejo', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:05:29', '54IMG_20170320_111309.jpg', '75', 1),
(669, 23, 'admin', 'R.Peringatan', 'rperingatan', 'Barat Perempatan Sukorejo\r\n', -7.53713, 111.68439, 'Jl. Supriyadi - Sukorejo', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:04:28', '58IMG_20170320_111211.jpg', '72', 1),
(667, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Barat Perempatan Sukorejo\r\n', -7.53713, 111.68439, 'Jl. Supriyadi - Sukorejo', 'Rusak', 'Terpasang', '', 'Kamis', '2017-05-11', '12:03:27', '79IMG_20170320_111106.jpg', '45', 1),
(668, 23, 'admin', 'R.Peringatan', 'rperingatan', 'Barat Perempatan Sukorejo\r\n', -7.53713, 111.68439, 'Jl. Supriyadi - Sukorejo', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:04:27', '6IMG_20170320_111211.jpg', '50', 1),
(666, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Barat Perempatan SUkorejo\r\n', -7.53713, 111.68439, 'Jl. Supriyadi - Sukorejo', 'sedang', 'Terpasang', '', 'Kamis', '2017-05-11', '12:02:25', '28IMG_20170320_111050.jpg', '19', 1),
(665, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Barat Perempatan Sukorejo\r\n', -7.53713, 111.68439, 'Jl. Supriyadi - Sukorejo', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '12:00:30', '48IMG_20170320_111000.jpg', '5', 1),
(664, 44, 'admin', 'LPJU', 'lpju', 'Perempatan KUD Sukorejo\r\n', -7.53589, 111.68037, 'Jl. Supriyadi - Sukorejo', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '11:59:27', '8IMG_20170320_110431.jpg', '68', 1),
(663, 22, 'admin', 'R.Peringatan', 'rperingatan', '<font size="3">Jl. Bener - Duren</font>\r\n', -7.51882, 111.67509, 'Jl.Bener - Duren', 'Baik', 'Terpasang', '2016', 'Kamis', '2017-05-11', '11:57:41', '70IMG_20170320_110431.jpg', '35', 1),
(662, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Jl.Bener - Duren\r\n', -7.51882, 111.67509, 'Jl.Bener - Duren', 'Baik', 'Terpasang', '2016', 'Kamis', '2017-05-11', '11:55:44', '23IMG_20170320_105549.jpg', '14', 1),
(660, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Timur SD Bajulan\r\n', -7.5328, 111.66702, 'Jl.Supriyadi - Bajulan', 'Rusak', 'Terpasang', '', 'Kamis', '2017-05-11', '11:51:45', '2IMG_20170320_103846.jpg', '20', 1),
(661, 41, 'admin', 'WL', 'wl', 'Timur SD Bajulan\r\n', -7.52965, 111.66731, 'Jl.Supriyadi - Bajulan', 'Baik', 'Terpasang', 'PAK 2016', 'Kamis', '2017-05-11', '11:52:56', '97IMG_20170320_104631.jpg', '24', 1),
(659, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'SD Bajulan\r\n', -7.5328, 111.66702, 'Jl.Supriyadi - Bajulan', 'Baik', 'Terpasang', 'PAK 2016', 'Kamis', '2017-05-11', '11:50:29', '35IMG_20170320_103811.jpg', '14', 1),
(654, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Depan Toko Kaca\r\n', -7.53163, 111.66159, 'Jl.Supriyadi - Bajulan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '11:26:32', '25IMG_20170321_093359.jpg', '73', 1),
(655, 19, 'admin', 'R. Petunjuk', 'r-petunjuk', 'Timur toko Kaca\r\n', -7.53163, 111.66159, 'Jl.Supriyadi - Bajulan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '11:44:50', '99IMG_20170320_100317.jpg', '8', 1),
(656, 36, 'admin', 'APILL', 'apill', 'Timur pertigaan Bajulan\r\n', -7.53163, 111.66159, 'Jl.Supriyadi - Bajulan', 'Baik', 'Terpasang', '', 'Kamis', '2017-05-11', '11:46:06', '14IMG_20170320_101923.jpg', '30', 1),
(657, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Depan MI Bajulan\r\n', -7.53185, 111.66379, 'Jl.Supriyadi - Bajulan', 'sedang', 'Terpasang', '2006', 'Kamis', '2017-05-11', '11:47:25', '34IMG_20170320_102516.jpg', '95', 1),
(658, 22, 'admin', 'R.Peringatan', 'rperingatan', 'Kantor Desa Bajulan\r\n', -7.53236, 111.66574, 'Jl.Supriyadi - Bajulan', 'Baik', 'Terpasang', 'PAK 2016', 'Kamis', '2017-05-11', '11:49:03', '23IMG_20170320_103228.jpg', '4', 1);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `judul` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `url` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `menu_order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=DYNAMIC AUTO_INCREMENT=43 ;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `parent_id`, `judul`, `url`, `menu_order`) VALUES
(1, 0, '< Home >', 'index.php', 1),
(2, 0, '< Tentang Kami >', 'tentangkami-kami.html', 2),
(12, 0, '< Hubungi Kami >', 'hubungi-kami.html', 5),
(27, 0, '< Institusi Kewilayahan >', '', 3),
(28, 0, '< Object Dishub >', '', 4),
(30, 27, 'Kantor', 'kategori-40.html', 1),
(32, 28, 'Rambu Perintah', 'kategori-21.html', 1),
(37, 28, 'Rambu Petunjuk', 'kategori-19.html', 6),
(34, 28, 'Cermin Tikungan', 'kategori-2.html', 4),
(35, 28, 'Rambu Peringatan', 'kategori-22.html', 3),
(36, 28, 'Apill', 'kategori-36.html', 5),
(38, 28, 'Rambu Perintah', 'kategori-21.html', 7);

-- --------------------------------------------------------

--
-- Table structure for table `modul`
--

CREATE TABLE IF NOT EXISTS `modul` (
  `id_modul` int(5) NOT NULL AUTO_INCREMENT,
  `nama_modul` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `link` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `static_content` text COLLATE latin1_general_ci NOT NULL,
  `gambar` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `publish` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  `status` enum('user','admin') COLLATE latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  `urutan` int(5) NOT NULL,
  `link_seo` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_modul`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=65 ;

--
-- Dumping data for table `modul`
--

INSERT INTO `modul` (`id_modul`, `nama_modul`, `link`, `static_content`, `gambar`, `publish`, `status`, `aktif`, `urutan`, `link_seo`) VALUES
(2, 'Manajemen User', '?module=user', '', '', 'N', 'user', 'Y', 1, ''),
(10, 'Manajemen Modul', '?module=modul', '', '', 'N', 'admin', 'Y', 2, ''),
(40, 'Hubungi Kami', '?module=hubungi', '', '', 'Y', 'admin', 'Y', 12, 'hubungi-kami.html'),
(58, 'Input Object', '?module=locations', '', '', 'Y', 'user', 'Y', 6, 'semua-locations.html'),
(59, 'Kategori Object', '?module=kategori', '', '', 'Y', 'admin', 'Y', 5, '""'),
(63, 'Tentang Kami', '?module=tentangkami', '<div align="justify">\r\n<font size="3">Transportasi mempunyai peranan yang sangat strategis dalam mendukung mobilitas masyarakat dan mobilitas barang. Transportasi jalan diselenggarakan dengan tujuan untuk mewujudkan lalu lintas dan angkutan jalan dengan selamat, aman, cepat, lancar, tertib, teratur, nyaman dan efisien dan mampu memadukan moda transportasi lainnya serta menjangkau seluruh pelosok daratan untuk menunjang pemerataan, pertumbuhan ekonomi dan stabilitas nasional. Sejalan dengan keberhasilan pembangunan di Kabupaten Madiun khususnya dibidang ekonomi akan berdampak pada tumbuhnya pusat-pusat kegiatan baru dan berkembangnya pusat-pusat kegiatan yang telah ada, hal ini akan menyebabkan meningkatnya mobilitas orang, barang maupun kendaraan.</font>\r\n</div>\r\n<div align="justify">\r\n<font size="3">Dalam pengendalian dan pengaturan transportasi khususnya transportasi darat keberadaan Sistem Informasi yang terstruktur dan terpola dengan baik akan sangat membantu Pemerintah dalam hal ini Dinas Perhubungan, Komunikasi dan Informatika Kabupaten Madiun. Karena dengan keberadaan sistem informasi mengenai transportasi darat akan memudahkan dalam memonitor dan manajemen transportasi darat. Kabupaten Madiun yang merupakan salah satu Kabupaten di Provinsi Jawa Timur yang saat ini masih terbatas sarana dan prasarana transportasi, khususnya transportasi darat. Untuk mencapai sistem jaringan transportasi yang handal, perlu adanya inventarisasi infrastruktur transportasi yang tersedia saat ini yaitu melalui Studi Sistem Database Perlengkapan Jalan, menjadi salah satu upaya yang dapat dilakukan oleh Pemerintah Daerah Kabupaten Madiun untuk dapat memetakan kondisi eksisting infrastruktur transportasi di Kabupaten Madiun, khususnya perlengkapan jalan.</font>\r\n</div>\r\n<div align="justify">\r\n<font size="3">Berdasarkan penjelasan di atas, muncul permasalahan yaitu bagaimana melakukan penyusunan database infrastruktur transportasi bidang perhubungan darat di Kabupaten Madiun. Database tersebut diimplementasikan dalam bentuk sistem informasi yang mampu menyimpan berbagai data dan informasi, menampilkan informasi perlengkapan jalan secara cepat dan akurat serta dilengkapi dengan informasi secara geografis (memuat data spasial), sehingga mampu menjadi alat bantu pendukung keputusan dan atau pengambil kebijakan oleh Pemerintah Daerah Kabupaten Madiun.</font>\r\n</div>\r\n<div align="justify">\r\n<font size="3">Berikut ini merupakan gambaran kegiatan dan realisasi pelayanan dari Dinas Perhubungan, Informatika dan Komunikasi Kabupaten Madiun yang turut serta dalam mendukung program dari Pemerintah yaitu melaksanakan pelayanan yang baik dan handal dalam bidang transportasi darat dengan menyediakan Database Perlengkapan Jalan berbasis Sistem Informasi Geografis guna mewujudkan transportasi yang aman, selamat, tertib dan lancar.</font><br />\r\n<font size="3">\r\n</font>\r\n</div>\r\n<br />\r\n', '181180_465926186770663_1551701293_n.jpg', 'Y', 'admin', 'Y', 3, 'tentangkami-kami.html'),
(64, 'Sekilas Links', '?module=sekilaslink', '', '', 'Y', 'admin', 'Y', 27, '""');

-- --------------------------------------------------------

--
-- Table structure for table `sekilaslink`
--

CREATE TABLE IF NOT EXISTS `sekilaslink` (
  `id_link` int(5) NOT NULL AUTO_INCREMENT,
  `nama_link` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `url` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `tgl_posting` date NOT NULL,
  PRIMARY KEY (`id_link`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=DYNAMIC AUTO_INCREMENT=11 ;

--
-- Dumping data for table `sekilaslink`
--

INSERT INTO `sekilaslink` (`id_link`, `nama_link`, `url`, `tgl_posting`) VALUES
(8, 'SIPKD', 'http://sipkd.bandarlampung.go.id/', '2012-06-27'),
(10, 'Budaya dan Pariwisata', 'http://disbudparkotabdl.net/', '2012-06-27');

-- --------------------------------------------------------

--
-- Table structure for table `shoutbox`
--

CREATE TABLE IF NOT EXISTS `shoutbox` (
  `id_shoutbox` int(5) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `website` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `pesan` text COLLATE latin1_general_ci NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id_shoutbox`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `shoutbox`
--

INSERT INTO `shoutbox` (`id_shoutbox`, `nama`, `website`, `pesan`, `tanggal`, `jam`, `aktif`) VALUES
(8, 'sdsa', 'sada', 'sadsa', '2013-05-16', '00:08:44', 'Y'),
(9, 'sad', 'asdas', '&lt;:D&gt;sadas\r\nsadsa', '2013-05-16', '00:09:05', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `nama_instansi` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `alamat` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `jabatan` varchar(15) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `no_telp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `level` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT 'user',
  `blokir` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `id_session` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `nama_instansi`, `alamat`, `jabatan`, `email`, `no_telp`, `level`, `blokir`, `id_session`) VALUES
('admin', '21232f297a57a5a743894a0e4a801fc3', 'Bangkit', 'terminal caruban', 'staff IT', 'dishubkabmadiun@gmail.com', '08562609852', 'admin', 'N', 'kh8f04vroe88v4ff21oce4l1h4'),
('kecamatansukarame', 'c1057a31328172ce50c877059afc73ca', 'Kecamatan Sukarame', 'Jalan Griya Utama No.3 Way Halim Permai', 'viviniz@yahoo.c', 'Staf It', '081978966733', 'user', 'N', 'c1057a31328172ce50c877059afc73ca'),
('kemiling', '545f98aef6fa831cf91a93eb4607cb92', 'kecamatankemiling', 'jl.segitu la', 'staff IT', '565', '085768666668', 'user', 'N', 'hebpb59kodu9pu1bve59nnkf50'),
('tanjungkarangpusat', '21232f297a57a5a743894a0e4a801fc3', 'tanjung karang pusat', 'Jalan Cut Nyak Dien', 'staff IT', '34', '085768666668', 'user', 'N', 'cbrq70mdin0o9ftpoeosg1cnt6'),
('tanjungkarangselatan', '153a5170244de75db154c484f149406c', 'Tanjung Karang Selatan', 'Jalan Cut Nyak Dien', 'staff IT', 'maton.tyasm@gmail.com', '085768666668', 'user', 'N', '153a5170244de75db154c484f149406c'),
('tanjungkarangtimur', '1b288aa8f69d16cf42bdc44892c56588', 'Tanjung Karang Timur', 'Jalan Mayor Jenderal Sutiyoso', 'aanlumut46@yaho', 'staff IT', '085768666668', 'user', 'N', '5it0arp9lfvgsuo7sub649u7c4');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
